/* Loader for the game's x86-64 image.
 *
 * The CPU side is architecture-independent: on x86-64 the guest code runs on the host CPU
 * (src/runtime_cpu.c), elsewhere it runs under FEXCore (cpu/, libgow3cpu.so). Everything that
 * crosses between host and guest goes through the boundary in src/guest_cpu.h, so this file has
 * no x86-64 machine-code assumptions of its own. */
#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <inttypes.h>
#include "runtime.h"
#include "guest_cpu.h"
#include "orb_hook.h"
#include "cheat_hook.h"
#include "actor_hook.h"
#include "damage_hook.h"
#include "gpu/gow3gpu.h"
#if !defined(__GNUC__)
#error This loader requires GCC or Clang.
#endif
#ifdef _WIN32
#include <windows.h>
#else
#include <sys/mman.h>
#include <malloc.h>
#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <fcntl.h>
#include <dlfcn.h>
#ifdef __ANDROID__
#include <unwind.h>
#include <sys/prctl.h>
#else
#include <execinfo.h>
#endif
#include <sys/syscall.h>
#include <sys/uio.h>
#endif

#if defined(__ANDROID__) && !defined(_WIN32)
typedef struct { void **frames; int count, max; } UnwindState;
static _Unwind_Reason_Code unwind_step(struct _Unwind_Context *context, void *argument) {
    UnwindState *state = argument;
    uintptr_t pc = _Unwind_GetIP(context);
    if (!pc) return _URC_END_OF_STACK;
    if (state->count >= state->max) return _URC_END_OF_STACK;
    state->frames[state->count++] = (void *)pc;
    return _URC_NO_REASON;
}
static int backtrace(void **frames, int max) {
    UnwindState state = {frames, 0, max};
    _Unwind_Backtrace(unwind_step, &state);
    return state.count;
}
#endif

typedef struct { uint64_t address, size, flags; } Segment;
typedef struct { uint64_t target, kind, value, addend; } Reloc;
static char (*names)[128];
static uint64_t import_count;
static unsigned char *image;
static size_t page_size;
typedef struct { uint64_t base, size, init, tls_address, tls_memsz, tls_filesz, tls_module; } LinkedModule;
static LinkedModule modules[16];
static uint64_t module_count;
static int entered_game;
static int gpu_enabled;
int vulkan_smoke(void);

static void fail(const char *message) { fprintf(stderr, "ERROR: %s\n", message); exit(1); }
static uint64_t read64(FILE *f) {
    unsigned char b[8];
    if (fread(b, 1, 8, f) != 8) fail("truncated boot file");
    uint64_t n = 0;
    for (int i = 7; i >= 0; --i) n = (n << 8) | b[i];
    return n;
}
static size_t round_page(size_t size) { return (size + page_size - 1) & ~(page_size - 1); }
static void *allocate(size_t size) {
    void *low=runtime_low_map(size,PROT_READ|PROT_WRITE);
    if (low) return low;
#ifdef _WIN32
    void *p = VirtualAlloc(NULL, size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (!p) fail("VirtualAlloc failed");
#else
    void *p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) fail("mmap failed");
#endif
    return p;
}
static void protect(void *p, size_t size, unsigned flags) {
#ifdef _WIN32
    DWORD old, mode = PAGE_NOACCESS;
    if (flags & 1) mode = (flags & 2) ? PAGE_EXECUTE_READWRITE : PAGE_EXECUTE_READ;
    else if (flags & 2) mode = PAGE_READWRITE;
    else if (flags & 4) mode = PAGE_READONLY;
    if (!VirtualProtect(p, size, mode, &old)) fail("VirtualProtect failed");
    FlushInstructionCache(GetCurrentProcess(), p, size);
#else
    int mode = ((flags & 4) ? PROT_READ : 0) | ((flags & 2) ? PROT_WRITE : 0) | ((flags & 1) ? PROT_EXEC : 0);
    if (mprotect(p, size, mode)) fail("mprotect failed");
#endif
}
static ABI __attribute__((noreturn)) void unresolved(uint32_t id, uintptr_t argument) {
    if (id >= import_count) fail("bad import trap index");
    printf("STOP: first unsupported PS4 import: %s (index %u)\n", names[id], id);
    printf("API: %s\n", runtime_import_name(names[id]));
    printf("Caller return offset: 0x%" PRIxPTR "; first argument: 0x%" PRIxPTR "\n",
           guest_cpu_return_address((uintptr_t)__builtin_return_address(0)) - (uintptr_t)image, argument);
    uintptr_t caller=guest_cpu_return_address((uintptr_t)__builtin_return_address(0))-(uintptr_t)image;
    for (uint64_t m=0;m<module_count;++m)
        if (caller>=modules[m].base && caller-modules[m].base<modules[m].size)
            printf("Caller in linked module %" PRIu64 " (%s): +0x%" PRIxPTR "\n",m,m==0 ? "libc.prx" : "system module",caller-modules[m].base);
    runtime_report();
    puts(entered_game ? "Original guest entry instructions executed; game initialization is incomplete." :
                        "Native libc initialization is incomplete; game entry has not run.");
    fflush(NULL);
    _exit(20); /* no destructors: GPU, audio and guest threads are still running */
}
#if defined(GUEST_CPU_NATIVE) && !defined(_WIN32)
/* enter_on_stack(entry, arg0, arg1, stack_top): call entry(arg0,arg1) on a new stack.
 * x86-64 hosts only: elsewhere (libgow3cpu.so) guest calls go through guest_cpu_call, which
 * switches to the guest stack itself. */
void enter_on_stack(void *entry, void *arg0, void *arg1, void *top);
__asm__(".text\n.globl enter_on_stack\nenter_on_stack:\n"
        " push %rbp\n mov %rsp,%rbp\n and $-16,%rcx\n mov %rcx,%rsp\n"
        " mov %rdi,%rax\n mov %rsi,%rdi\n mov %rdx,%rsi\n call *%rax\n"
        " mov %rbp,%rsp\n pop %rbp\n ret\n");
#endif
static ABI void guest_exit(void) { puts("Runtime: process finalizer callback reached"); }
#ifdef _WIN32
static void describe_address(char *out, size_t size, uintptr_t address) {
    HMODULE module=NULL;
    char name[MAX_PATH]="?";
    if (image && address-(uintptr_t)image<0x20000000) { snprintf(out,size,"guest offset 0x%" PRIxPTR,address-(uintptr_t)image); return; }
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)address,&module) && module) {
        GetModuleFileNameA(module,name,sizeof(name));
        const char *base=strrchr(name,'\\');
        snprintf(out,size,"%s+0x%" PRIxPTR,base ? base+1 : name,address-(uintptr_t)module);
        return;
    }
    snprintf(out,size,"%p",(void *)address);
}
static int fatal_reported;
static LONG fatal_exception(EXCEPTION_POINTERS *info) {
    if (__atomic_exchange_n(&fatal_reported,1,__ATOMIC_ACQ_REL)) { Sleep(INFINITE); }
    const EXCEPTION_RECORD *record=info->ExceptionRecord;
    const CONTEXT *c=info->ContextRecord;
    char where[MAX_PATH+64];
    describe_address(where,sizeof(where),(uintptr_t)c->Rip);
    if (record->ExceptionCode==EXCEPTION_ACCESS_VIOLATION && record->NumberParameters>=2)
        fprintf(stderr,"Fault: %s access to %p at %s (thread %lu)\n",
                record->ExceptionInformation[0]==1 ? "write" : record->ExceptionInformation[0]==8 ? "execute" : "read",
                (void *)record->ExceptionInformation[1],where,GetCurrentThreadId());
    else
        fprintf(stderr,"Fault: exception 0x%08lx at %s (thread %lu)\n",record->ExceptionCode,where,GetCurrentThreadId());
    fprintf(stderr,"  rax=%016llx rbx=%016llx rcx=%016llx rdx=%016llx\n  rsi=%016llx rdi=%016llx rbp=%016llx rsp=%016llx\n",
            c->Rax,c->Rbx,c->Rcx,c->Rdx,c->Rsi,c->Rdi,c->Rbp,c->Rsp);
    if (gpu_enabled) gow3gpu_dump_guest_writes(info);
    /* rbp chain (guest and host code keep frame pointers). */
    uintptr_t rbp=(uintptr_t)c->Rbp;
    for (int depth=0; depth<24 && rbp; ++depth) {
        uintptr_t frame[2];
        SIZE_T got=0;
        if (!ReadProcessMemory(GetCurrentProcess(),(void *)rbp,frame,sizeof(frame),&got) || got!=sizeof(frame) || frame[0]<=rbp) break;
        describe_address(where,sizeof(where),frame[1]);
        fprintf(stderr,"  #%d %s\n",depth,where);
        rbp=frame[0];
    }
    fflush(NULL);
    TerminateProcess(GetCurrentProcess(),3);
    return EXCEPTION_CONTINUE_SEARCH;
}
static LONG CALLBACK vectored_fault(EXCEPTION_POINTERS *info) {
    const EXCEPTION_RECORD *record=info->ExceptionRecord;
    DWORD code=record->ExceptionCode;
    if (code==EXCEPTION_ACCESS_VIOLATION && record->NumberParameters>=2) {
        /* GPU page tracking (write-protected guest pages) is resolved first. */
        if (gpu_enabled && gow3gpu_handle_fault(info,(void *)record->ExceptionInformation[1])) return EXCEPTION_CONTINUE_EXECUTION;
        if (runtime_fault_recover) {
            /* A speculative guest memory read (GPU draw preparation) faulted: the thread resumes
             * in gow3_longjmp, outside the exception dispatcher, back at its recovery point. */
            unsigned long long *buffer=*runtime_fault_recover;
            runtime_fault_recover=NULL;
            CONTEXT *c=info->ContextRecord;
            c->Rsp=((c->Rsp-128)&~(DWORD64)15)-40;
            c->Rcx=(DWORD64)(uintptr_t)buffer;
            c->Rdx=1;
            c->Rip=(DWORD64)(uintptr_t)gow3_longjmp;
            return EXCEPTION_CONTINUE_EXECUTION;
        }
    }
    if (code==EXCEPTION_ACCESS_VIOLATION || code==EXCEPTION_ILLEGAL_INSTRUCTION || code==EXCEPTION_PRIV_INSTRUCTION ||
        code==EXCEPTION_STACK_OVERFLOW || code==EXCEPTION_INT_DIVIDE_BY_ZERO || code==EXCEPTION_DATATYPE_MISALIGNMENT) {
        /* Faults in guest code, the loader or the runtime end the process with a report; drivers
         * and system libraries may handle their own exceptions. */
        uintptr_t rip=(uintptr_t)info->ContextRecord->Rip;
        HMODULE self=GetModuleHandleA(NULL), module=NULL;
        int ours=(image && rip-(uintptr_t)image<0x20000000) ||
                 (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,(LPCSTR)rip,&module) && module==self) ||
                 !module;
        if (ours) return fatal_exception(info);
    }
    /* GOW3_STRICT_HANDLES=1: a closed or invalid handle used anywhere is reported (diagnostics). */
    if (code==0xC0000008 /* STATUS_INVALID_HANDLE */) return fatal_exception(info);
    return EXCEPTION_CONTINUE_SEARCH;
}
static LONG WINAPI unhandled_fault(EXCEPTION_POINTERS *info) { return fatal_exception(info); }
/* Guest code reads its TCB with `mov rax, gs:[0]` (link_*.py rewrote fs:[0]); on Windows
 * the displacement becomes the TEB TLS slot that holds the guest TCB (runtime_thread.c). */
uint32_t runtime_thread_tcb_offset(void);
static uint64_t patch_tcb_loads(const Segment *segments, uint64_t count) {
    static const unsigned char load[]={0x65,0x48,0x8b,0x04,0x25,0,0,0,0};
    uint32_t displacement=runtime_thread_tcb_offset();
    uint64_t patched=0;
    for (uint64_t s=0;s<count;++s) {
        if (!(segments[s].flags&1) || segments[s].size<sizeof(load)) continue;
        unsigned char *at=image+segments[s].address, *end=at+segments[s].size-sizeof(load);
        for (; at<=end; ++at)
            if (at[0]==0x65 && !memcmp(at,load,sizeof(load))) { memcpy(at+5,&displacement,4); ++patched; at+=sizeof(load)-1; }
    }
    return patched;
}
#endif
#ifndef _WIN32
int runtime_watch_handle_fault(int sig,siginfo_t *info,void *context);
static void fault(int sig, siginfo_t *info, void *context) {
    /* GPU page tracking gets first chance to resolve its own protected-page faults. */
    if (gpu_enabled && sig == SIGSEGV && gow3gpu_handle_fault(context, info->si_addr)) return;
    /* GOW3_WATCH_A_V2_ORDER: then handle the diagnostic watch on the A page. */
    if (runtime_watch_handle_fault(sig,info,context)) return;
    /* Faults the guest CPU itself raises (JIT bookkeeping) are handled and resumed. */
    if (guest_cpu_handle_fault(sig, info, context)) return;
    /* A speculative guest memory read (runtime_memory.c) failed: resume its recovery point. */
    if ((sig == SIGSEGV || sig == SIGBUS) && runtime_fault_recover) {
        sigjmp_buf *recover = runtime_fault_recover;
        runtime_fault_recover = NULL;
        sigset_t unblock;
        sigemptyset(&unblock);
        sigaddset(&unblock, sig);
        pthread_sigmask(SIG_UNBLOCK, &unblock, NULL);
        siglongjmp(*recover, 1);
    }
    /* The process is terminating: dladdr/snprintf are acceptable here. */
    GuestRegs regs;
    const int in_guest = guest_cpu_signal_regs(context, &regs);
    uintptr_t rip = in_guest == GUEST_CPU_IN_GUEST ? (uintptr_t)regs.rip : guest_cpu_host_pc(context);
    char line[1024];
    Dl_info where;
    if (rip - (uintptr_t)image < 0x10000000)
        snprintf(line, sizeof(line), "Guest fault (signal %d) at guest offset 0x%lx, address %p\n",
                 sig, (unsigned long)(rip - (uintptr_t)image), info->si_addr);
    else if (dladdr((void *)rip, &where) && where.dli_fname)
        snprintf(line, sizeof(line), "Host fault (signal %d) in %s+0x%lx (%s), address %p\n", sig, where.dli_fname,
                 (unsigned long)(rip - (uintptr_t)where.dli_fbase), where.dli_sname ? where.dli_sname : "?", info->si_addr);
    else
        snprintf(line, sizeof(line), "Fault (signal %d) at RIP %p, address %p\n", sig, (void *)rip, info->si_addr);
    { ssize_t written_=write(2, line, strlen(line)); (void)written_; }
    /* Extra crash context: thread, guest/host state, last guest->host call, and the mapping that holds the PC. */
    {
        char tname[32]="?";
#ifdef __ANDROID__
        prctl(PR_GET_NAME,(unsigned long)tname,0,0,0);
#endif
        snprintf(line,sizeof(line),"  thread='%s' tid=%ld in_guest=%d image=%p last_guest_call_ret=0x%lx (image+0x%lx) guest_sp=0x%lx\n",
                 tname,(long)gettid(),in_guest,(void *)image,(unsigned long)guest_cpu_return_address(0),
                 (unsigned long)(guest_cpu_return_address(0)-(uintptr_t)image),(unsigned long)guest_cpu_stack_pointer());
        { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
        if (in_guest) {
            snprintf(line,sizeof(line),"  guest rip=0x%lx (image+0x%lx) rsp=0x%lx rbp=0x%lx rax=0x%lx rcx=0x%lx rdx=0x%lx rbx=0x%lx rsi=0x%lx rdi=0x%lx\n",
                     (unsigned long)regs.rip,(unsigned long)(regs.rip-(uintptr_t)image),(unsigned long)regs.gpr[GUEST_RSP],(unsigned long)regs.gpr[GUEST_RBP],
                     (unsigned long)regs.gpr[GUEST_RAX],(unsigned long)regs.gpr[GUEST_RCX],(unsigned long)regs.gpr[GUEST_RDX],(unsigned long)regs.gpr[GUEST_RBX],
                     (unsigned long)regs.gpr[GUEST_RSI],(unsigned long)regs.gpr[GUEST_RDI]);
            { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
            snprintf(line,sizeof(line),"  guest r8=0x%lx r9=0x%lx r10=0x%lx r11=0x%lx r12=0x%lx r13=0x%lx r14=0x%lx r15=0x%lx\n",
                     (unsigned long)regs.gpr[GUEST_R8],(unsigned long)regs.gpr[GUEST_R9],(unsigned long)regs.gpr[GUEST_R10],(unsigned long)regs.gpr[GUEST_R11],
                     (unsigned long)regs.gpr[GUEST_R12],(unsigned long)regs.gpr[GUEST_R13],(unsigned long)regs.gpr[GUEST_R14],(unsigned long)regs.gpr[GUEST_R15]);
            { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
        }
#if defined(__aarch64__)
        {
            const ucontext_t *uc=(const ucontext_t *)context;
            snprintf(line,sizeof(line),"  host pc=0x%lx sp=0x%lx fault_addr=0x%lx\n",(unsigned long)uc->uc_mcontext.pc,(unsigned long)uc->uc_mcontext.sp,(unsigned long)uc->uc_mcontext.fault_address);
            { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
            for (int i=0;i<31;i+=4) {
                snprintf(line,sizeof(line),"  x%d=0x%lx x%d=0x%lx x%d=0x%lx x%d=0x%lx\n",i,(unsigned long)uc->uc_mcontext.regs[i],
                         i+1,(unsigned long)uc->uc_mcontext.regs[i+1],i+2,(unsigned long)uc->uc_mcontext.regs[i+2],
                         i+3<31?i+3:30,(unsigned long)uc->uc_mcontext.regs[i+3<31?i+3:30]);
                { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
            }
        }
#endif
        {
            /* Safe reads (process_vm_readv) so a bad pointer cannot fault again. */
            #define SAFE_READ(dst,addr,len) ({ struct iovec l_={(dst),(len)}, r_={(void *)(uintptr_t)(addr),(len)}; process_vm_readv(getpid(),&l_,1,&r_,1,0)==(ssize_t)(len); })
            static char maps[1<<20]; size_t used=0; int mfd=open("/proc/self/maps",O_RDONLY);
            if (mfd>=0) { ssize_t n; while (used<sizeof(maps)-1 && (n=read(mfd,maps+used,sizeof(maps)-1-used))>0) used+=(size_t)n; close(mfd); }
            maps[used]=0;
            uintptr_t probes[3]={rip,0,0};
#if defined(__aarch64__)
            probes[1]=((const ucontext_t *)context)->uc_mcontext.regs[30];
            probes[2]=((const ucontext_t *)context)->uc_mcontext.regs[28];
#endif
            for (int k=0;k<3;++k) {
                if (!probes[k]) continue;
                char *ln=maps;
                while (ln && *ln) {
                    char *nl=strchr(ln,'\n'); if (nl) *nl=0;
                    unsigned long lo=0,hi=0;
                    if (sscanf(ln,"%lx-%lx",&lo,&hi)==2 && probes[k]>=lo && probes[k]<hi) {
                        snprintf(line,sizeof(line),"  %s mapping: %s (offset in mapping 0x%lx)\n",k==0?"pc":k==1?"lr":"x28",ln,(unsigned long)(probes[k]-lo));
                        { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
                        break;
                    }
                    if (nl) *nl='\n';
                    ln=nl?nl+1:NULL;
                }
            }
            unsigned char code[64];
            if (SAFE_READ(code,rip-32,sizeof(code))) {
                int o=snprintf(line,sizeof(line),"  code around pc (pc-32..pc+32):");
                for (size_t i=0;i<sizeof(code) && o<(int)sizeof(line)-4;++i) o+=snprintf(line+o,sizeof(line)-(size_t)o," %02x",code[i]);
                snprintf(line+o,sizeof(line)-(size_t)o,"\n"); { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
            }
            /* Guest stack: return addresses (image offsets) show who called what. */
            uintptr_t gsp=in_guest ? (uintptr_t)regs.gpr[GUEST_RSP] : 0;
            uint64_t stk[48];
            if (gsp && SAFE_READ(stk,gsp,sizeof(stk))) {
                for (int i=0;i<48;i+=4) {
                    snprintf(line,sizeof(line),"  gstack+0x%x: %lx %lx %lx %lx\n",i*8,(unsigned long)stk[i],(unsigned long)stk[i+1],(unsigned long)stk[i+2],(unsigned long)stk[i+3]);
                    { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
                }
                for (int i=0;i<48;++i)
                    if (stk[i]>=(uintptr_t)image && stk[i]<(uintptr_t)image+0x3000000) {
                        snprintf(line,sizeof(line),"  gstack ret candidate [%d]: image+0x%lx\n",i,(unsigned long)(stk[i]-(uintptr_t)image));
                        { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
                    }
            }
            /* Guest code bytes (x86-64) around the likely crash site and the stack return addresses, to disassemble offline. */
            {
                uintptr_t sites[10]; int ns_=0;
#if defined(__aarch64__)
                sites[ns_++]=((const ucontext_t *)context)->uc_mcontext.regs[20];
#endif
                if (gsp && SAFE_READ(stk,gsp,sizeof(stk)))
                    for (int i=0;i<48 && ns_<10;++i)
                        if (stk[i]>=(uintptr_t)image && stk[i]<(uintptr_t)image+0x3000000) sites[ns_++]=stk[i];
                for (int k=0;k<ns_;++k) {
                    unsigned char b[96];
                    if (!SAFE_READ(b,sites[k]-64,sizeof(b))) continue;
                    int o=snprintf(line,sizeof(line),"  guest code image+0x%lx (-64..+32):",(unsigned long)(sites[k]-(uintptr_t)image));
                    for (size_t i=0;i<sizeof(b) && o<(int)sizeof(line)-4;++i) o+=snprintf(line+o,sizeof(line)-(size_t)o,"%02x",b[i]);
                    snprintf(line+o,sizeof(line)-(size_t)o,"\n"); { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
                }
            }
#if defined(__aarch64__)
            /* FEX keeps its CPU state (guest RIP first, then the 16 GPRs) at the pointer in x28/x0. */
            const uintptr_t st[2]={((const ucontext_t *)context)->uc_mcontext.regs[28],((const ucontext_t *)context)->uc_mcontext.regs[0]};
            for (int k=0;k<2;++k) {
                uint64_t q[20];
                if (st[k] && SAFE_READ(q,st[k],sizeof(q))) {
                    snprintf(line,sizeof(line),"  state@%lx rip?=%lx (image+0x%lx) g0-3=%lx %lx %lx %lx\n",(unsigned long)st[k],(unsigned long)q[0],(unsigned long)(q[0]-(uintptr_t)image),(unsigned long)q[1],(unsigned long)q[2],(unsigned long)q[3],(unsigned long)q[4]);
                    { ssize_t w_=write(2,line,strlen(line)); (void)w_; }
                }
            }
#endif
        }
    }
    if (gpu_enabled) gow3gpu_dump_guest_writes(context);
    /* Host call chain (frames with unwind info; guest frames end it). */
    void *frames[32];
    int depth = backtrace(frames, 32);
    for (int i = 2; i < depth; ++i) {
        if (dladdr(frames[i], &where) && where.dli_fname)
            snprintf(line, sizeof(line), "  #%d %s+0x%lx (%s)\n", i, where.dli_fname,
                     (unsigned long)((uintptr_t)frames[i] - (uintptr_t)where.dli_fbase), where.dli_sname ? where.dli_sname : "?");
        else
            snprintf(line, sizeof(line), "  #%d %p\n", i, frames[i]);
        ssize_t written_=write(2, line, strlen(line)); (void)written_;
    }
    _exit(128 + sig);
}
#endif
#ifndef _WIN32
/* Watchdog: dump RIP and the rbp frame chain of every thread (guest offsets
 * when inside the image). Reads use process_vm_readv so bad frames cannot fault. */
static uintptr_t exe_base;
static void write_hex(char *out, uint64_t v) {
    const char digits[] = "0123456789abcdef";
    for (int i = 0; i < 16; ++i) out[i] = digits[(v >> (60 - i * 4)) & 15];
}
static void dump_frames(ucontext_t *uc) {
    char line[] = "  tid=0000000000000000 rip=0000000000000000 image-relative=0000000000000000 host-relative=0000000000000000\n";
    /* Guest registers come from the boundary: on x86-64 hosts the signal interrupted guest code;
     * with the JIT the signal may be in host code between guest calls (guest_cpu_host_pc). */
    GuestRegs regs;
    const int in_guest = guest_cpu_signal_regs(uc, &regs);
    uintptr_t rip = in_guest ? (uintptr_t)regs.rip : guest_cpu_host_pc(uc);
    uintptr_t rbp = in_guest ? (uintptr_t)regs.gpr[GUEST_RBP] : 0;
    uint64_t tid=(uint64_t)gettid();
    /* First argument register: the lock address when a thread waits on a futex. */
    char arg[]="  tid=0000000000000000 rdi=0000000000000000\n";
    write_hex(arg+6,tid); write_hex(arg+27,(uint64_t)(in_guest ? regs.gpr[GUEST_RDI] : 0));
    { ssize_t written_=write(2,arg,sizeof(arg)-1); (void)written_; }
    for (int depth=0; depth<24; ++depth) {
        write_hex(line+6,tid); write_hex(line+27,rip); write_hex(line+59,rip-(uintptr_t)image); write_hex(line+90,rip-exe_base);
        { ssize_t written_=write(2,line,sizeof(line)-1); (void)written_; }
        uintptr_t frame[2];
        struct iovec local={frame,sizeof(frame)}, remote={(void *)rbp,sizeof(frame)};
        if (!rbp || process_vm_readv(getpid(),&local,1,&remote,1,0)!=(ssize_t)sizeof(frame)) break;
        if (frame[0]<=rbp) break;
        rbp=frame[0]; rip=frame[1];
    }
}
static void thread_dump(int sig, siginfo_t *info, void *context) { (void)sig; (void)info; dump_frames(context); }
static void watchdog(int sig, siginfo_t *info, void *context) {
    (void)info;
    const char head[]="STOP: watchdog timeout; thread stacks:\n";
    { ssize_t written_=write(2,head,sizeof(head)-1); (void)written_; }
    dump_frames(context);
    int dir=open("/proc/self/task",O_RDONLY|O_DIRECTORY);
    char buffer[4096];
    long n;
    pid_t self=gettid();
    while (dir>=0 && (n=syscall(SYS_getdents64,dir,buffer,sizeof(buffer)))>0)
        for (long at=0; at<n;) {
            struct { uint64_t ino; int64_t off; unsigned short reclen; unsigned char type; char name[]; } *d=(void *)(buffer+at);
            pid_t tid=(pid_t)strtol(d->name,NULL,10);
            if (tid>0 && tid!=self) { syscall(SYS_tgkill,getpid(),tid,SIGUSR2); usleep(20000); }
            at+=d->reclen;
        }
    usleep(100000);
    _exit(128 + sig);
}
#endif
/* param.sfo lookup: string or integer value of key, 0 when absent. */
static int sfo_value(const char *path, const char *key, char *text, size_t text_size, uint32_t *number) {
    FILE *f=fopen(path,"rb");
    if (!f) return 0;
    unsigned char data[65536];
    size_t n=fread(data,1,sizeof(data),f); fclose(f);
    if (n<20 || memcmp(data,"\0PSF",4)) return 0;
    uint32_t keys, values, count;
    memcpy(&keys,data+8,4); memcpy(&values,data+12,4); memcpy(&count,data+16,4);
    for (uint32_t i=0;i<count && 20+i*16+16<=n;++i) {
        const unsigned char *e=data+20+i*16;
        uint16_t key_offset, format; uint32_t length, offset;
        memcpy(&key_offset,e,2); memcpy(&format,e+2,2); memcpy(&length,e+4,4); memcpy(&offset,e+12,4);
        if (keys+key_offset>=n || values+offset+length>n || strcmp((const char *)data+keys+key_offset,key)) continue;
        if (format==0x0404 && number && length>=4) { memcpy(number,data+values+offset,4); return 1; }
        if (text && text_size) {
            size_t copy=length<text_size-1 ? length : text_size-1;
            memcpy(text,data+values+offset,copy); text[copy]=0;
        }
        return 1;
    }
    return 0;
}
static int mapped(Segment *segments, uint64_t count, uint64_t address, uint64_t bytes) {
    for (uint64_t i = 0; i < count; ++i)
        if (address >= segments[i].address && bytes <= segments[i].size &&
            address - segments[i].address <= segments[i].size - bytes) return 1;
    return 0;
}
extern ABI float gow3_orbs_gain(void *player, float requested);
extern void gow3_orbs_status(int supported);
extern uintptr_t gow3_cheat_flag(unsigned id);
extern uintptr_t gow3_actor_slots_address(void);
extern void gow3_actor_status(int supported);
extern void gow3_cheat_status(unsigned id);
extern uintptr_t gow3_damage_multiplier(int taken);
extern uintptr_t gow3_orb_pickup_multiplier(unsigned kind);
extern void gow3_stat_multipliers_status(int damage, int orb_pickup);

/* The hook installers write x86-64 machine-code stubs into the image; they only apply when the
 * guest runs on the host CPU. Under the JIT this needs guest_cpu_hook (not wired yet), so they
 * are compiled out there (their calls below are gated the same way). */
#if defined(GUEST_CPU_NATIVE)
static void install_cheats(const char *app0, Segment *segments, uint64_t count, uint64_t size) {
    char path[4096], serial[32] = "", version[32] = "";
    snprintf(path, sizeof(path), "%s/sce_sys/param.sfo", app0 ? app0 : ".");
    sfo_value(path, "TITLE_ID", serial, sizeof(serial), NULL);
    sfo_value(path, "APP_VER", version, sizeof(version), NULL);
    if (strcmp(serial, "CUSA01623") || strcmp(version, "01.02")) return;
    const char *names[] = {"health", "magic", "item meter", "Rage of Sparta", "red orbs",
                           "Very Hard unlock", "infinite double jumps"};
    for (unsigned id = 0; id < GOW3_CHEAT_COUNT; ++id) {
        int valid = 1;
        for (unsigned i = 0; i < GOW3_CHEAT_HOOK_COUNT; ++i) {
            const Gow3CheatHook *hook = &gow3_cheat_hooks[i];
            if (hook->id != id) continue;
            if (hook->offset > size || hook->length > size - hook->offset ||
                !mapped(segments, count, hook->offset, hook->length) ||
                !gow3_cheat_signature_match(hook, image + hook->offset, size - hook->offset)) valid = 0;
        }
        if (!valid) {
            printf("Cheats: %s unavailable (code signature mismatch)\n", names[id]);
            continue;
        }
        unsigned char *stubs = allocate(page_size);
        int32_t relative[GOW3_CHEAT_HOOK_COUNT] = {0};
        for (unsigned i = 0; i < GOW3_CHEAT_HOOK_COUNT; ++i) {
            const Gow3CheatHook *hook = &gow3_cheat_hooks[i];
            if (hook->id != id) continue;
            unsigned char *stub = stubs + i * 256;
            int64_t delta = (int64_t)(uintptr_t)stub - (int64_t)(uintptr_t)(image + hook->offset + 5);
            if (delta < INT32_MIN || delta > INT32_MAX) { valid = 0; break; }
            relative[i] = (int32_t)delta;
            gow3_cheat_build_stub(stub, hook, gow3_cheat_flag(id),
                                 (uintptr_t)(image + hook->offset + hook->length));
        }
        if (!valid) {
            printf("Cheats: %s unavailable (hook outside relative-jump range)\n", names[id]);
            continue;
        }
        protect(stubs, page_size, 5);
        for (unsigned i = 0; i < GOW3_CHEAT_HOOK_COUNT; ++i) {
            const Gow3CheatHook *hook = &gow3_cheat_hooks[i];
            if (hook->id != id) continue;
            image[hook->offset] = 0xe9;
            memcpy(image + hook->offset + 1, &relative[i], 4);
            memset(image + hook->offset + 5, 0x90, hook->length - 5);
        }
        gow3_cheat_status(id);
        printf("Cheats: %s ready (live toggle, initially disabled unless saved)\n", names[id]);
    }
}

/* Damage hook for the enemy health bar (src/actor_hook.h). Always
 * installed when the code matches: it only records values; the overlay decides what to show. */
static void install_actor_watch(const char *app0, Segment *segments, uint64_t count, uint64_t size) {
    char path[4096], serial[32] = "", version[32] = "";
    snprintf(path, sizeof(path), "%s/sce_sys/param.sfo", app0 ? app0 : ".");
    sfo_value(path, "TITLE_ID", serial, sizeof(serial), NULL);
    sfo_value(path, "APP_VER", version, sizeof(version), NULL);
    const uint64_t at = GOW3_ACTOR_HOOK_OFFSET;
    if (strcmp(serial, "CUSA01623") || strcmp(version, "01.02") || at > size ||
        !mapped(segments, count, at, GOW3_ACTOR_HOOK_LENGTH) ||
        !gow3_actor_signature_match(image + at, size - at)) {
        printf("Health display: unavailable (game version or code signature mismatch)\n");
        return;
    }
    unsigned char *stub = allocate(page_size);
    const int64_t delta = (int64_t)(uintptr_t)stub - (int64_t)(uintptr_t)(image + at + 5);
    if (delta < INT32_MIN || delta > INT32_MAX) {
        printf("Health display: unavailable (hook outside relative-jump range)\n");
        return;
    }
    gow3_actor_build_stub(stub, gow3_actor_slots_address(), (uintptr_t)(image + at + GOW3_ACTOR_HOOK_LENGTH));
    protect(stub, page_size, 5);
    const int32_t relative = (int32_t)delta;
    image[at] = 0xe9;
    memcpy(image + at + 1, &relative, 4);
    memset(image + at + 5, 0x90, GOW3_ACTOR_HOOK_LENGTH - 5);
    gow3_actor_status(1);
    printf("Health display: damage hook ready (enemy health bar in the menu)\n");
}

static void install_orb_multiplier(const char *app0, Segment *segments, uint64_t count,
                                   uint64_t size) {
    char path[4096], serial[32] = "", version[32] = "";
    snprintf(path, sizeof(path), "%s/sce_sys/param.sfo", app0 ? app0 : ".");
    sfo_value(path, "TITLE_ID", serial, sizeof(serial), NULL);
    sfo_value(path, "APP_VER", version, sizeof(version), NULL);
    if (strcmp(serial, "CUSA01623") || strcmp(version, "01.02") ||
        !gow3_orb_signatures_match(image, size)) {
        printf("Red orbs: multiplier unavailable (game version or gain signatures mismatch)\n");
        return;
    }
    for (unsigned i = 0; i < 3; ++i) {
        if (!mapped(segments, count, gow3_orb_calls[i], 5)) return;
    }
    /* SysV call sites: preserve the receiver across the helper, then tail-call the original
     * setter. Its cap and upgrade notifications remain in the game's own code. */
    unsigned char *stub = allocate(page_size);
    uintptr_t helper = (uintptr_t)gow3_orbs_gain, setter = (uintptr_t)(image + 0x6a9f0);
    unsigned char code[26];
    gow3_orb_build_stub(code, helper, setter);
    int32_t displacements[3];
    for (unsigned i = 0; i < 3; ++i) {
        int64_t delta = (int64_t)(uintptr_t)stub - (int64_t)(uintptr_t)(image + gow3_orb_calls[i] + 5);
        if (delta < INT32_MIN || delta > INT32_MAX) {
            printf("Red orbs: multiplier unavailable (hook outside relative-call range)\n");
            return;
        }
        displacements[i] = (int32_t)delta;
    }
    memcpy(stub, code, sizeof(code));
    protect(stub, page_size, 5);
    for (unsigned i = 0; i < 3; ++i)
        memcpy(image + gow3_orb_calls[i] + 1, &displacements[i], 4);
    gow3_orbs_status(1);
    printf("Red orbs: live multiplier ready (3 validated gain paths, 0.1x to 100x)\n");
}
/* Writes a jump from image+at to `stub`; the rest of the replaced bytes become nops (the stub
 * replays them). 0 when the stub is out of relative-jump range. */
static int install_jump(uint64_t at, unsigned length, unsigned char *stub) {
    const int64_t delta = (int64_t)(uintptr_t)stub - (int64_t)(uintptr_t)(image + at + 5);
    if (delta < INT32_MIN || delta > INT32_MAX) return 0;
    const int32_t relative = (int32_t)delta;
    image[at] = 0xe9;
    memcpy(image + at + 1, &relative, 4);
    memset(image + at + 5, 0x90, length - 5);
    return 1;
}

/* Damage dealt/taken and green/blue/gold orb multipliers (src/damage_hook.h, src/orb_hook.h):
 * the stubs read the menu's floats directly, so changes apply on the next hit or pickup. */
static void install_stat_multipliers(const char *app0, Segment *segments, uint64_t count, uint64_t size) {
    char path[4096], serial[32] = "", version[32] = "";
    snprintf(path, sizeof(path), "%s/sce_sys/param.sfo", app0 ? app0 : ".");
    sfo_value(path, "TITLE_ID", serial, sizeof(serial), NULL);
    sfo_value(path, "APP_VER", version, sizeof(version), NULL);
    const int game = !strcmp(serial, "CUSA01623") && !strcmp(version, "01.02");
    const uint64_t damage_at = GOW3_DAMAGE_HOOK_OFFSET, pickup_at = GOW3_ORB_PICKUP_OFFSET;
    int damage = game && damage_at < size && mapped(segments, count, damage_at, GOW3_DAMAGE_HOOK_LENGTH) &&
                 gow3_damage_signature_match(image + damage_at, size - damage_at);
    int pickup = game && pickup_at < size && mapped(segments, count, pickup_at, GOW3_ORB_PICKUP_LENGTH) &&
                 gow3_orb_pickup_signature_match(image + pickup_at, size - pickup_at);
    unsigned char *stubs = damage || pickup ? allocate(page_size) : NULL;
    if (damage) {
        gow3_damage_build_stub(stubs, gow3_damage_multiplier(1), gow3_damage_multiplier(0),
                               (uintptr_t)(image + damage_at + GOW3_DAMAGE_HOOK_LENGTH));
    }
    if (pickup) {
        gow3_orb_pickup_build_stub(stubs + 256, gow3_orb_pickup_multiplier(0), gow3_orb_pickup_multiplier(1),
                                   gow3_orb_pickup_multiplier(2),
                                   (uintptr_t)(image + pickup_at + GOW3_ORB_PICKUP_LENGTH));
    }
    if (stubs) protect(stubs, page_size, 5);
    damage = damage && install_jump(damage_at, GOW3_DAMAGE_HOOK_LENGTH, stubs);
    pickup = pickup && install_jump(pickup_at, GOW3_ORB_PICKUP_LENGTH, stubs + 256);
    gow3_stat_multipliers_status(damage, pickup);
    printf("Multipliers: damage %s, green/blue/gold orbs %s\n", damage ? "ready" : "unavailable",
           pickup ? "ready" : "unavailable");
}
/* G3PATCH2 (patches.py): the patches' image base, then byte writes at image offsets, applied
 * after relocation. A write may replace a whole base-relative pointer slot (60/90 FPS++ swap
 * function pointers): the patch holds the address at the patches' base, rebased here. */
#endif

static void apply_patches(const char *path, Segment *segments, uint64_t ns, const Reloc *relocs, uint64_t nr) {
    FILE *f=fopen(path,"rb");
    char magic[8];
    if (!f || fread(magic,1,8,f)!=8 || memcmp(magic,"G3PATCH2",8)) fail("invalid patch file");
    uint64_t base=read64(f), count=read64(f), bytes=0, rebased=0;
    unsigned char data[4096];
    for (uint64_t i=0;i<count;++i) {
        uint64_t offset=read64(f), length=read64(f);
        if (!length || length>sizeof(data) || !mapped(segments,ns,offset,length) || fread(data,1,length,f)!=length)
            fail("bad patch entry");
        uint64_t slots[sizeof(data)/8]; size_t nslots=0;
        for (uint64_t r=0;r<nr;++r) {
            if (!(relocs[r].target<offset+length && offset<relocs[r].target+8)) continue;
            uint64_t target=relocs[r].target, value;
            if (relocs[r].kind || target<offset || target+8>offset+length) fail("patch overlaps a relocation");
            memcpy(&value,data+(target-offset),8);
            if (value<base || !mapped(segments,ns,value-base,1)) fail("patch writes a pointer outside the image");
            slots[nslots++]=target;
        }
        memcpy(image+offset,data,length);
        for (size_t s=0;s<nslots;++s) {
            uint64_t value;
            memcpy(&value,image+slots[s],8);
            value=(uint64_t)(uintptr_t)image+(value-base);
            memcpy(image+slots[s],&value,8);
        }
        rebased+=nslots;
        bytes+=length;
    }
    if (fgetc(f)!=EOF) fail("trailing data in patch file");
    fclose(f);
    printf("Patches: %" PRIu64 " writes, %" PRIu64 " bytes applied, %" PRIu64 " pointers rebased\n",count,bytes,rebased);
}
/* Restarts the game through run.sh (the settings menu: a new render resolution is a patch
 * applied at start). Descriptors are closed first so the old GPU device and its memory are
 * released before the new process opens its own. */
void runtime_restart(void) {
    fflush(NULL);
#ifdef _WIN32
    /* run.py sets GOW3_RESTART_COMMAND: the launch command line, started again (new patches). */
    const char *command=getenv("GOW3_RESTART_COMMAND");
    puts("Runtime: restarting through run.py");
    if (!command || !*command) { fputs("runtime_restart: GOW3_RESTART_COMMAND is not set\n",stderr); _exit(1); }
    char *line=_strdup(command);
    /* Same output handles: a launcher reading the game's log keeps reading the new launch. */
    STARTUPINFOA startup={.cb=sizeof(startup),.dwFlags=STARTF_USESTDHANDLES,
                          .hStdInput=GetStdHandle(STD_INPUT_HANDLE),.hStdOutput=GetStdHandle(STD_OUTPUT_HANDLE),
                          .hStdError=GetStdHandle(STD_ERROR_HANDLE)};
    PROCESS_INFORMATION process;
    if (!line || !CreateProcessA(NULL,line,NULL,NULL,TRUE,0,NULL,NULL,&startup,&process)) {
        fprintf(stderr,"runtime_restart: CreateProcess failed (%lu)\n",GetLastError()); _exit(1);
    }
    CloseHandle(process.hThread); CloseHandle(process.hProcess);
    /* The new launch waits for this process's GPU device to go away (run.py --after). */
    TerminateProcess(GetCurrentProcess(),0);
#else
    puts("Runtime: restarting through run.sh");
#ifdef __ANDROID__
    // close_range is blocked by Android seccomp on supported devices.
    long max_fd = sysconf(_SC_OPEN_MAX);
    for (int fd = 3; fd < (max_fd > 0 ? max_fd : 65536); ++fd) close(fd);
    const char* runner = getenv("GOW3_BIONIC_RUNNER");
    if (runner && *runner) execl("/system/bin/sh", "sh", runner, "game", (char*)NULL);
#else
    syscall(SYS_close_range, 3u, ~0u, 0u);
    execlp("bash", "bash", "run.sh", (char *)NULL);
#endif
    perror("runtime_restart: exec");
    _exit(1);
#endif
}

void runtime_file_stats(unsigned long long *o,unsigned long long *r,unsigned long long *b,unsigned long long *m);
size_t runtime_sema_snapshot(char *out,size_t size);
void runtime_file_progress(void);
void runtime_file_snapshot(void);
#ifndef _WIN32
/* Heartbeat: one line every 5 s with RSS, available RAM and thread count. If the log just stops,
 * the last line shows whether the process was starved of memory (Android kills it silently) or hung. */
#include <pthread.h>
static void *heartbeat_thread(void *arg) {
    (void)arg;
    for (unsigned n=1;;++n) {
        sleep(5);
        unsigned long rss_pages=0,total=0; FILE *f=fopen("/proc/self/statm","r");
        if (f) { if (fscanf(f,"%lu %lu",&total,&rss_pages)!=2) rss_pages=0; fclose(f); }
        unsigned long avail_kb=0,swap_kb=0; char key[64]; unsigned long v; f=fopen("/proc/meminfo","r");
        if (f) { while (fscanf(f,"%63s %lu kB",key,&v)==2) { if (!strcmp(key,"MemAvailable:")) avail_kb=v; else if (!strcmp(key,"SwapFree:")) swap_kb=v; } fclose(f); }
        unsigned threads=0; f=fopen("/proc/self/status","r");
        if (f) { char l[128]; while (fgets(l,sizeof(l),f)) if (sscanf(l,"Threads: %u",&threads)==1) break; fclose(f); }
        fprintf(stderr,"Heartbeat #%u: rss=%lu MiB, MemAvailable=%lu MiB, SwapFree=%lu MiB, threads=%u | gpu flips submitted=%llu presented=%llu draws=%llu dispatches=%llu\n",n,rss_pages*(unsigned long)sysconf(_SC_PAGESIZE)/1048576UL,avail_kb/1024,swap_kb/1024,threads,gow3gpu_stat(0),gow3gpu_stat(1),gow3gpu_stat(2),gow3gpu_stat(3));
        { unsigned long long fo,fr,fb,fm; runtime_file_stats(&fo,&fr,&fb,&fm); fprintf(stderr,"Heartbeat files: opens=%llu reads=%llu read=%llu MiB not_found=%llu\n",fo,fr,fb/1048576ULL,fm); runtime_file_progress(); runtime_file_snapshot(); }
        {
            const char *tn[8]; uint64_t td[8]={0}; size_t k=guest_cpu_stub_top(tn,td,8);
            if (k>8) k=8;
            char cl[512]; int o=snprintf(cl,sizeof(cl),"Heartbeat calls (5 s):");
            for (size_t i=0;i<k && o<(int)sizeof(cl)-64;++i) o+=snprintf(cl+o,sizeof(cl)-(size_t)o," %s=%llu",tn[i],(unsigned long long)td[i]);
            fprintf(stderr,"%s\n",cl);
            char ts[1024]; guest_cpu_thread_states(ts,sizeof(ts));
            fprintf(stderr,"Heartbeat threads:%s\n",ts);
            char sm[512]; runtime_sema_snapshot(sm,sizeof(sm));
            fprintf(stderr,"Heartbeat semas:%s\n",sm);
        }
        fflush(stderr);
    }
    return NULL;
}
#endif
int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IONBF, 0);
#ifdef __ANDROID__
    /* The launcher tracks the runner shell. Kill the native child too when the
       app stops/restarts that shell, including during an internal game restart. */
    pid_t parent = getppid();
    if (parent == 1 || prctl(PR_SET_PDEATHSIG, SIGKILL) != 0 || getppid() != parent) {
        fputs("Bionic: launcher parent is unavailable\n", stderr);
        return 2;
    }
#endif
#ifndef _WIN32
    /* Keep host heap objects handed to the guest (thread handles, TLS) in the
       non-PIE brk heap, i.e. below 1 TiB: the guest packs pointers into 40 bits. */
#ifdef __ANDROID__
    // Scudo does not support glibc's brk-heap tunables. Guest code stores 40-bit pointers;
    // runtime_low_map remains responsible for allocations crossing the guest boundary.
    mallopt(M_BIONIC_SET_HEAP_TAGGING_LEVEL, M_HEAP_TAGGING_LEVEL_NONE);
#else
    mallopt(M_ARENA_MAX,1);
    mallopt(M_MMAP_THRESHOLD,32*1024*1024);
#endif
    /* The guest CPU allocates the memory the guest may hold pointers to through this (below
     * 1 TiB). No-op on x86-64 hosts (src/runtime_cpu.c). */
    guest_cpu_init(runtime_low_map);
#endif
    if (argc == 2 && !strcmp(argv[1], "--vulkan-only")) return vulkan_smoke();
#ifdef _WIN32
    /* The PS4 user range must stay free of host allocations (GPU driver, heaps), and the guest
     * TCB needs one of the 64 TEB TLS slots before DLLs (Vulkan drivers) take them. */
    runtime_memory_reserve();
    runtime_thread_tcb_offset();
#endif
    int cpu_only = 0, strict_imports = 0, check_imports = 0;
    unsigned timeout_seconds = 10;
    const char *content_profile=NULL, *app0=NULL, *user_dir=NULL, *patch_file=NULL;
    for (int i = 2; i < argc; ++i) {
        if (!strcmp(argv[i], "--cpu-only")) cpu_only = 1;
        else if (!strcmp(argv[i], "--strict-imports")) strict_imports = 1;
        else if (!strcmp(argv[i], "--check-imports")) check_imports = 1;
        else if (!strcmp(argv[i], "--content-profile") && i+1<argc) content_profile=argv[++i];
        else if (!strcmp(argv[i], "--app0") && i+1<argc) app0=argv[++i];
        else if (!strcmp(argv[i], "--user") && i+1<argc) user_dir=argv[++i];
        else if (!strcmp(argv[i], "--patches") && i+1<argc) patch_file=argv[++i];
        else if (!strcmp(argv[i], "--timeout") && i+1<argc) timeout_seconds=(unsigned)strtoul(argv[++i],NULL,10);
        else { fprintf(stderr, "Unknown option: %s\n", argv[i]); return 1; }
    }
    if (argc < 2) {
        fprintf(stderr, "Usage: %s boot.bin [--cpu-only] [--strict-imports] [--check-imports] [--content-profile file] [--app0 dir] [--user dir] [--patches file] [--timeout seconds] | --vulkan-only\n", argv[0]);
        return 1;
    }
    if (content_profile) {
        FILE *profile=fopen(content_profile,"rb");
        unsigned char data[28];
        if (!profile) fail("cannot open content profile");
        if (fread(data,1,sizeof(data),profile)!=sizeof(data) || fgetc(profile)!=EOF || memcmp(data,"G3CONT01",8)) fail("invalid content profile");
        fclose(profile);
        uint32_t values[5];
        for (unsigned i=0;i<5;++i) {
            unsigned char *p=data+8+i*4;
            values[i]=(uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
        }
        runtime_content_configure(values);
    }
    if (app0) {
        runtime_file_configure(app0, user_dir ? user_dir : "user");
        char sfo[4096], id[16]="";
        snprintf(sfo,sizeof(sfo),"%s/sce_sys/param.sfo",app0);
        if (sfo_value(sfo,"INSTALL_DIR_SAVEDATA",id,sizeof(id),NULL) || sfo_value(sfo,"TITLE_ID",id,sizeof(id),NULL))
            runtime_savedata_configure(id);
    }
    gow3gpu_register_kernel();
#ifdef _WIN32
    SYSTEM_INFO system_info; GetSystemInfo(&system_info); page_size = system_info.dwPageSize;
    AddVectoredExceptionHandler(1, vectored_fault);
    SetUnhandledExceptionFilter(unhandled_fault);
    if (getenv("GOW3_STRICT_HANDLES")) {
        PROCESS_MITIGATION_STRICT_HANDLE_CHECK_POLICY strict={0};
        strict.RaiseExceptionOnInvalidHandleReference=1;
        strict.HandleExceptionsPermanentlyEnabled=1;
        if (!SetProcessMitigationPolicy(ProcessStrictHandleCheckPolicy,&strict,sizeof(strict)))
            fprintf(stderr,"GOW3_STRICT_HANDLES: policy not set (%lu)\n",GetLastError());
    }
    (void)timeout_seconds; /* no watchdog on Windows */
#else
    page_size = (size_t)sysconf(_SC_PAGESIZE);
    struct sigaction sa = {0}; sa.sa_sigaction = fault; sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, NULL); sigaction(SIGILL, &sa, NULL); sigaction(SIGBUS, &sa, NULL);
    Dl_info self_info;
    if (dladdr((void *)main,&self_info)) exe_base=(uintptr_t)self_info.dli_fbase;
    struct sigaction dump = {0}; dump.sa_sigaction = thread_dump; dump.sa_flags = SA_SIGINFO|SA_RESTART;
    sigemptyset(&dump.sa_mask); sigaction(SIGUSR2, &dump, NULL);
    struct sigaction alarm_action = {0}; alarm_action.sa_sigaction = watchdog; alarm_action.sa_flags = SA_SIGINFO;
    sigemptyset(&alarm_action.sa_mask); sigaction(SIGALRM, &alarm_action, NULL);
    alarm(timeout_seconds); /* 0 disables the watchdog */
#endif
    FILE *f = fopen(argv[1], "rb");
    if (!f) fail("cannot open boot file; run prepare.py first");
    char magic[8];
    if (fread(magic, 1, 8, f) != 8 || (memcmp(magic, "G3PROBE1", 8) && memcmp(magic, "G3PROBE2", 8) && memcmp(magic,"G3PROBE3",8) && memcmp(magic,"G3PROBE4",8) && memcmp(magic,"G3PROBE5",8))) fail("bad boot file signature");
    uint64_t size = read64(f), entry = read64(f), ns = read64(f), nr = read64(f);
    import_count = read64(f);
    uint64_t capabilities = memcmp(magic, "G3PROBE1", 8) ? read64(f) : 0;
    if (capabilities & ~UINT64_C(1)) fail("unknown runtime capabilities");
    runtime_start(strict_imports ? 0 : capabilities);
    if (!size || size > 512*1024*1024 || entry >= size || !ns || ns > 64 || nr > 1000000 || import_count > 100000)
        fail("boot file limits exceeded");
    int multi=!memcmp(magic,"G3PROBE5",8);
    int linked=!memcmp(magic,"G3PROBE3",8) || !memcmp(magic,"G3PROBE4",8) || multi;
    int native_libc=linked && !strict_imports && (capabilities&1);
    uint64_t main_tls[4]={0};
    uint64_t nb=0,procparam=0;
    uint64_t *bindings=calloc(import_count ? import_count : 1,sizeof(*bindings));
    uint64_t *binding_kinds=calloc(import_count ? import_count : 1,sizeof(*binding_kinds));
    if (!bindings || !binding_kinds) fail("allocation failed");
    if (multi) {
        /* G3PROBE5: procparam, eboot TLS, module table, bindings (link_modules.py). */
        procparam=read64(f);
        for (int i=0;i<4;++i) main_tls[i]=read64(f);
        module_count=read64(f);
        if (!module_count || module_count>sizeof(modules)/sizeof(*modules)) fail("invalid module count");
        for (uint64_t m=0;m<module_count;++m) {
            LinkedModule *x=&modules[m];
            x->base=read64(f); x->size=read64(f); x->init=read64(f); x->tls_address=read64(f);
            x->tls_memsz=read64(f); x->tls_filesz=read64(f); x->tls_module=read64(f);
        }
        nb=read64(f);
    } else if (linked) {
        LinkedModule *x=&modules[0];
        module_count=1;
        x->base=read64(f); x->size=read64(f); x->init=read64(f);
        x->tls_address=read64(f); x->tls_memsz=read64(f); x->tls_filesz=read64(f); x->tls_module=2; nb=read64(f);
        procparam=read64(f);
        if (!memcmp(magic,"G3PROBE4",8)) for (int i=0;i<4;++i) main_tls[i]=read64(f);
    }
    if (linked) {
        if (main_tls[1]>main_tls[2] || main_tls[2]>1024*1024 || main_tls[0]>size ||
            main_tls[1]>size-main_tls[0] || (main_tls[3] & (main_tls[3]-1)) || main_tls[3]>4096)
            fail("invalid eboot TLS metadata");
        for (uint64_t m=0;m<module_count;++m) {
            LinkedModule *x=&modules[m];
            if (x->base>=size || !x->size || x->size>size-x->base || x->init<x->base || x->init-x->base>=x->size ||
                (x->tls_module && (x->tls_address>=size || x->tls_memsz>size-x->tls_address || x->tls_memsz>1024*1024 ||
                                   x->tls_filesz>x->tls_memsz || x->tls_module<2 || x->tls_module>7)))
                fail("invalid linked module metadata");
        }
        if (nb>import_count) fail("invalid binding count");
        for (uint64_t i=0;i<nb;++i) {
            uint64_t index=read64(f),address=read64(f),kind=read64(f);
            int inside=0;
            for (uint64_t m=0;m<module_count;++m)
                if (address>=modules[m].base && address-modules[m].base<modules[m].size) inside=1;
            if (index>=import_count || !inside || (kind!=1 && kind!=2) || bindings[index]) fail("invalid native binding");
            bindings[index]=address; binding_kinds[index]=kind;
        }
    }
    Segment *segments = calloc(ns, sizeof(*segments));
    Reloc *relocs = calloc(nr ? nr : 1, sizeof(*relocs));
    names = calloc(import_count ? import_count : 1, sizeof(*names));
    if (!segments || !relocs || !names) fail("allocation failed");
    for (uint64_t i = 0; i < ns; ++i) {
        segments[i].address = read64(f);
        segments[i].size = read64(f);
        segments[i].flags = read64(f);
        if (segments[i].address > size || segments[i].size > size - segments[i].address ||
            segments[i].address % page_size || segments[i].flags > 7) fail("bad segment");
    }
    if (fread(names, 128, import_count, f) != import_count) fail("truncated import names");
    for (uint64_t i = 0; i < import_count; ++i)
        if (!memchr(names[i], 0, 128)) fail("unterminated import name");
    for (uint64_t i = 0; i < nr; ++i) {
        relocs[i].target = read64(f);
        relocs[i].kind = read64(f);
        relocs[i].value = read64(f);
        relocs[i].addend = read64(f);
        if (!mapped(segments, ns, relocs[i].target, 8) || relocs[i].kind > 2 ||
            (relocs[i].kind && relocs[i].value >= import_count) ||
            (relocs[i].kind != 2 && relocs[i].addend) || relocs[i].addend >= page_size) fail("bad relocation");
    }
    for (uint64_t m=0;m<module_count;++m)
        if (!mapped(segments,ns,modules[m].init,1) || (modules[m].tls_module && !mapped(segments,ns,modules[m].tls_address,modules[m].tls_memsz)))
            fail("unmapped module metadata");
    if (module_count && !mapped(segments,ns,procparam,64)) fail("unmapped procparam");
    for (uint64_t i=0;i<import_count;++i) {
        if (!bindings[i]) continue;
        if (!mapped(segments,ns,bindings[i],1)) fail("unmapped native export");
        if (binding_kinds[i]==1) {
            int executable=0;
            for (uint64_t s=0;s<ns;++s)
                if ((segments[s].flags&1) && bindings[i]>=segments[s].address &&
                    bindings[i]-segments[s].address<segments[s].size) executable=1;
            if (!executable) fail("native function is not executable");
        }
    }
    image = allocate(round_page(size));
    if (fread(image, 1, size, f) != size || fgetc(f) != EOF) fail("incorrect memory image size");
    fclose(f);
    if (!cpu_only) {
        char title[128]="God of War III", serial[16]="UNKNOWN", sfo[4096];
        uint32_t attributes=0;
        snprintf(sfo,sizeof(sfo),"%s/sce_sys/param.sfo",app0 ? app0 : ".");
        sfo_value(sfo,"TITLE",title,sizeof(title),NULL);
        sfo_value(sfo,"TITLE_ID",serial,sizeof(serial),NULL);
        sfo_value(sfo,"ATTRIBUTE",NULL,0,&attributes);
        uint64_t sdk=0;
        if (procparam) memcpy(&sdk,image+procparam+16,8); /* procparam: size, magic, count, sdk_version */
        Gow3GpuConfig gpu={title,serial,user_dir ? user_dir : "user",(uint32_t)sdk,attributes,1920,1080};
        gpu_enabled=1; /* page tracking starts while the rasterizer registers guest memory */
        if (gow3gpu_init(&gpu)) fail("GPU initialization failed");
        printf("GPU: window and Vulkan presenter ready; SDK 0x%08x, %u HLE symbols\n",(unsigned)sdk,gow3gpu_symbol_count());
    }
    unsigned char *traps = allocate(round_page((import_count + 1) * 32));
    unsigned char *data_traps = allocate((import_count + 1) * page_size);
    protect(data_traps, (import_count + 1) * page_size, 0);
    /* Guest code ranges: the image itself and the import traps. Done through the boundary so the
     * JIT can translate them (no-op on x86-64 hosts). */
    guest_cpu_code((uintptr_t)image, round_page(size));
    guest_cpu_code((uintptr_t)traps, round_page((import_count + 1) * 32));
    /* The stub below jumps here as guest code: on x86-64 this is the raw function; with the JIT
     * it is the guest-callable thunk for it. */
    const uintptr_t handler = guest_cpu_host_function((void *)unresolved);
    for (uint64_t i = 0; i < import_count; ++i) {
        unsigned char *t = traps + i * 32;
        /* SysV: mov edi, index; movabs rax, handler; jmp rax. No fake return values. */
        uint32_t index = (uint32_t)i;
        t[0] = 0x48; t[1] = 0x89; t[2] = 0xfe; /* mov rsi,rdi: preserve arg0 */
        t[3] = 0xbf; memcpy(t + 4, &index, 4);
        t[8] = 0x48; t[9] = 0xb8; memcpy(t + 10, &handler, 8);
        t[18] = 0xff; t[19] = 0xe0;
    }
    for (uint64_t i = 0; i < nr; ++i) {
        uintptr_t value = relocs[i].kind == 2 ? (uintptr_t)(data_traps + page_size * relocs[i].value + relocs[i].addend)
                        : relocs[i].kind == 1 ? (uintptr_t)(traps + 32 * relocs[i].value)
                        : (uintptr_t)image + relocs[i].value;
        if (relocs[i].kind) {
            uintptr_t resolved = runtime_resolve(names[relocs[i].value], relocs[i].kind == 2);
            /* Host functions handed to the guest are wrapped: the guest calls them in its own
             * convention, the boundary converts (a plain cast on x86-64 hosts). */
            if (resolved && relocs[i].kind == 1) { value = guest_cpu_host_function((void *)resolved); guest_cpu_name_stub(value, runtime_import_name(names[relocs[i].value])); }
            else if (resolved) value = resolved + relocs[i].addend;
            else if (native_libc && bindings[relocs[i].value]) {
                uint64_t address=bindings[relocs[i].value];
                if (binding_kinds[relocs[i].value]!=relocs[i].kind || !mapped(segments,ns,address,relocs[i].addend+1)) fail("native export kind/range mismatch");
                value=(uintptr_t)image+address+relocs[i].addend;
            }
        }
        memcpy(image + relocs[i].target, &value, 8);
    }
    {
        /* Lists every import the game would stop at (always printed, so one run shows them all);
         * --check-imports stops here without running the game (needs the GPU
         * library: without --cpu-only its symbols are registered above). */
        unsigned char *checked=calloc(import_count ? import_count : 1,1);
        if (!checked) fail("allocation failed");
        uint64_t missing=0;
        for (uint64_t i=0;i<nr;++i) {
            uint64_t index=relocs[i].value;
            if (!relocs[i].kind || checked[index]) continue;
            checked[index]=1;
            if (runtime_resolve(names[index],relocs[i].kind==2) || (native_libc && bindings[index])) continue;
            printf("MISSING: %s (%s)\n",names[index],runtime_import_name(names[index]));
            ++missing;
        }
        printf("Imports: %" PRIu64 " missing\n",missing);
        fflush(NULL);
        if (check_imports) _exit(missing ? 1 : 0); /* no destructors: GPU threads are running */
    }
    if (patch_file) apply_patches(patch_file, segments, ns, relocs, nr);
#if defined(GUEST_CPU_NATIVE)
    /* These hooks write x86-64 machine-code stubs straight into the image (0xe9 jumps), which is
     * only meaningful when the game's code runs on the host CPU. Under the JIT the image is
     * translated, so live code patching needs the JIT's own hook path (guest_cpu_hook, not yet
     * wired here): the game runs without cheats, the health bar and the orb multipliers. */
    if (gpu_enabled) install_orb_multiplier(app0, segments, ns, size);
    if (gpu_enabled) install_cheats(app0, segments, ns, size);
    if (gpu_enabled) install_actor_watch(app0, segments, ns, size);
    if (gpu_enabled) install_stat_multipliers(app0, segments, ns, size);
#else
    (void)segments; (void)ns;
#endif
#ifdef _WIN32
    printf("Guest TCB loads redirected to the TEB TLS slot: %" PRIu64 "\n", patch_tcb_loads(segments, ns));
#endif
    protect(traps, round_page((import_count + 1) * 32), 5);
    {
        /* This title keeps its fixed 64 KiB direct-map address as a 64-bit immediate in the code
         * (movabs r14, 0xfaaaa00000 at image offset 0xcd01b), stored later into a global. That
         * value lies above what this phone can map. Every unaligned occurrence is replaced by
         * 0x1000040000, which the runtime mapped in the test. Only the exact value is touched. */
        const uint64_t old_hint = 0xfaaaa00000ull, new_hint = 0x1000040000ull;
        unsigned char pat[8], rep[8];
        uint64_t count = 0;
        memcpy(pat, &old_hint, 8);
        memcpy(rep, &new_hint, 8);
        for (uint64_t off = 0; off + 8 <= size; ++off) {
            if (memcmp(image + off, pat, 8) == 0) {
                memcpy(image + off, rep, 8);
                if (count < 8)
                    printf("Patched image offset 0x%" PRIx64 ": 0x%" PRIx64 " -> 0x%" PRIx64 "\n", off, old_hint, new_hint);
                ++count;
                off += 7;
            }
        }
        printf("Hint patch: %" PRIu64 " occurrence(s) of 0x%" PRIx64 " replaced\n", count, old_hint);
    }
    {
        /* `int 0x41` is the SDK's debugger break (assert). The game runs on past it when no debugger is
         * attached (the code after it is the normal failure path), but FEX turns it into a fatal fault.
         * Replaced by two NOPs at: image offset 0x32a4f7 (seen crashing), plus every offset listed (hex,
         * one per line) in /sdcard/Download/gow2018_int41_offsets.txt (made by scan_int41.py). Only
         * bytes that are exactly cd 41 are touched. */
        uint64_t done = 0, skipped = 0;
        uint64_t offs[4096]; size_t no = 0;
        offs[no++] = 0x32a4f7;
        FILE *lf = fopen("/sdcard/Download/gow2018_int41_offsets.txt", "r");
        if (lf) {
            char l[64];
            while (no < 4096 && fgets(l, sizeof(l), lf)) {
                char *e; unsigned long long v = strtoull(l, &e, 16);
                if (e != l) offs[no++] = v;
            }
            fclose(lf);
        }
        for (size_t i = 0; i < no; ++i) {
            if (offs[i] + 2 <= size && image[offs[i]] == 0xcd && image[offs[i] + 1] == 0x41) {
                image[offs[i]] = 0x90; image[offs[i] + 1] = 0x90; ++done;
            } else ++skipped;
        }
        printf("INT 0x41 patch: %" PRIu64 " site(s) replaced by NOPs, %" PRIu64 " skipped\n", done, skipped);
    }
    protect(image, round_page(size), 0);
    int executable_entry = 0;
    for (uint64_t i = 0; i < ns; ++i) {
        protect(image + segments[i].address, round_page(segments[i].size), (unsigned)segments[i].flags);
        if ((segments[i].flags & 1) && entry >= segments[i].address && entry - segments[i].address < segments[i].size)
            executable_entry = 1;
    }
    if (!executable_entry) fail("entry is not executable");
    printf("Mapped %" PRIu64 " bytes, %" PRIu64 " segments; applied %" PRIu64 " relocations\n", size, ns, nr);
    printf("Image base: %p (guest rip - base = image offset)\n", (void *)image);
    {
        /* Dump of the loaded, relocated image: offsets in the file equal image offsets. */
        /* Written from the segment table, not by reading the whole image: the image is no-access
         * outside its segments, so gaps are written as zeros and only readable segments are copied. */
        FILE *dump = fopen("/sdcard/Download/gow2018_image.bin", "wb");
        if (dump) {
            static unsigned char zeros[1 << 20];
            uint64_t pos = 0, failed = 0;
            while (pos < size && !failed) {
                uint64_t stop = size, step = 0;
                int copy = 0;
                for (uint64_t i = 0; i < ns; ++i) {
                    uint64_t a = segments[i].address, b = a + segments[i].size;
                    if (pos >= a && pos < b) { stop = b < size ? b : size; copy = (segments[i].flags & 4) != 0; break; }
                    if (a > pos && a < stop) stop = a;
                }
                step = stop - pos;
                while (step > 0 && !failed) {
                    uint64_t n = step < (1u << 20) ? step : (1u << 20);
                    size_t w = copy ? fwrite(image + pos, 1, (size_t)n, dump)
                                    : fwrite(zeros, 1, (size_t)n, dump);
                    if (w != (size_t)n) {
                        printf("Image dump stopped at %" PRIu64 " of %" PRIu64 " bytes: errno=%d (%s)\n",
                               pos + w, size, errno, strerror(errno));
                        failed = 1;
                        break;
                    }
                    pos += n; step -= n;
                }
            }
            fclose(dump);
            printf("Image dumped to /sdcard/Download/gow2018_image.bin: %" PRIu64 " of %" PRIu64 " bytes\n", pos, size);
        } else {
            printf("Image dump failed: %s (storage permission?)\n", strerror(errno));
        }
    }
    if (native_libc) {
        for (uint64_t m=0;m<module_count;++m) {
            int init_executable=0;
            for (uint64_t i=0;i<ns;++i)
                if ((segments[i].flags&1) && modules[m].init>=segments[i].address && modules[m].init-segments[i].address<segments[i].size) init_executable=1;
            if (!init_executable) fail("module init is not executable");
            if (modules[m].tls_module)
                runtime_set_module_tls(modules[m].tls_module,image+modules[m].tls_address,modules[m].tls_filesz,modules[m].tls_memsz);
        }
        runtime_set_main_tls(image+main_tls[0],main_tls[1],main_tls[2],main_tls[3]);
        runtime_thread_attach_main();
        runtime_set_procparam(image+procparam);
        /* Dependencies start in link order (libc first), as the PS4 dynamic linker does. */
        for (uint64_t m=0;m<module_count;++m) {
            printf("Starting linked module %" PRIu64 " at image offset 0x%" PRIx64 "; native bindings=%" PRIu64 "\n",m,modules[m].init,nb);
            const uint64_t init_args[3]={0,0,0};
            int result=(int)guest_cpu_call((uintptr_t)(image+modules[m].init),3,init_args);
            printf("Module %" PRIu64 " initializer returned %d\n",m,result);
            if (result) fail("module initializer failed");
        }
    }
    printf("Entering original x86-64 code at guest offset 0x%" PRIx64 "\n", entry);
    entered_game=1;
#ifndef _WIN32
    { pthread_t hb_; if (!pthread_create(&hb_,NULL,heartbeat_thread,NULL)) pthread_detach(hb_); }
#endif
    /* Static: the host stack may lie above 47-bit guest addresses (arm64 hosts). */
    static struct { uint64_t argc; const char *argv[2]; } params = {1, {"/app0/eboot.bin", NULL}};
#ifdef _WIN32
    typedef void (ABI *Entry)(void *, void (ABI *)(void));
    ((Entry)(image + entry))(&params, guest_exit);
#else
    /* The guest main thread runs on a stack below 1 TiB like PS4 stacks. */
    enum { MAIN_STACK=8*1024*1024 };
    unsigned char *stack=runtime_low_map(MAIN_STACK,PROT_READ|PROT_WRITE);
    if (!stack) fail("cannot allocate guest main stack");
#if defined(GUEST_CPU_NATIVE)
    enter_on_stack(image+entry,&params,(void *)guest_exit,stack+MAIN_STACK-64);
#else
    /* Tell the guest CPU where this thread's guest stack is, then enter the image through the
     * boundary: it converts to the guest's convention and runs the JIT. */
    guest_cpu_thread_stack(stack+MAIN_STACK-64,MAIN_STACK-64);
    const uint64_t entry_args[2]={(uint64_t)(uintptr_t)&params,guest_cpu_host_function((void *)guest_exit)};
    guest_cpu_call((uintptr_t)(image+entry),2,entry_args);
#endif
#endif
    fail("entry unexpectedly returned");
}

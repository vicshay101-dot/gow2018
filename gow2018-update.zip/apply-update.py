#!/usr/bin/env python3
"""Fix terrain/ground SRT regression while keeping particle shaders + shadows clean.

Root cause of terrain texture regression in v19:
- All 26 terrain/ground shaders (54c287e5, 86c19976, 2e168c7a..a222e2a5) use BOTH
  FindILsb32 (8..166 times) AND 1..2 GetAttributeU32 nodes outside FindILsb32.
  Disabling GetAttributeU32 globally left all 26 terrain shaders with unresolved=1.
- The 3 particle compute shaders (38c7b95b, c78d8517, cbfa423f) have ZERO FindILsb32
  nodes in their SRT offset trees.

Fix (ShaderBinaryVersion / ShaderMetaVersion = 20u):
1. Gate the full stage-2 SRT fallback (GetAttributeU32->0 + FindILsb32 tile-0/slot-0)
   strictly on SrtSubtreeHasFindILsb(pass_info):
   - All 26 terrain/ground shaders -> SrtSubtreeHasFindILsb == true -> unresolved=0 (solid terrain).
   - The 3 particle shaders -> SrtSubtreeHasFindILsb == false -> untouched (no red diagonal streak).
2. Keep clean visual defaults: GOW3_SHADOW_RATE=1, GOW3_VOLFOG_RATE=1, GOW3_VOL3D_RATE=1,
   GOW3_HOT_PAGES=0, GOW3_DESCRIPTOR_TEMPLATE=0, GOW3_COALESCE_COMPUTE_BARRIERS=0,
   and no temporal volumetric shaders in ShouldSkipVolumetricFog.
"""
from pathlib import Path


def patch_any(rel_path: str, olds: list[str], new: str) -> None:
    p = Path(rel_path)
    if not p.exists():
        raise FileNotFoundError(f"[fail] missing file: {rel_path}")
    text = p.read_text(encoding="utf-8")
    for old in olds:
        if old in text:
            p.write_text(text.replace(old, new, 1), encoding="utf-8")
            print(f"[ok] patched: {rel_path}")
            return
    if new and new in text:
        print(f"[skip] already patched: {rel_path}")
        return
    raise RuntimeError(f"[fail] expected block not found in {rel_path}")


# 1. vk_pipeline_common.cpp: ensure const void* cast
patch_any(
    "gpu/shadps4/video_core/renderer_vulkan/vk_pipeline_common.cpp",
    ["                cmdbuf.pushDescriptorSetWithTemplateKHR(update, layout, 0, buffers.data());"],
    "                cmdbuf.pushDescriptorSetWithTemplateKHR(update, layout, 0,\n"
    "                                                        static_cast<const void*>(buffers.data()));",
)

# 2a. flatten_extended_userdata_pass.cpp: restore g_force_zero_find_lsb + ValueContainsOpcode + SrtSubtreeHasFindILsb
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    [
        """static thread_local bool g_suppress_unflattened_log = false;
static thread_local bool g_allow_dynamic_index_fallback = false;
static thread_local u32 g_dynamic_fallback_hits = 0;

static bool DependsOnAttribute(const IR::Value& value, int depth,
                               std::vector<const IR::Inst*>& visited) {
    if (depth <= 0 || value.IsImmediate()) {
        return false;
    }
    const IR::Inst* inst = value.TryInst();
    if (!inst) {
        return false;
    }
    if (inst->GetOpcode() == IR::Opcode::GetAttributeU32) {
        return true;
    }
    if (std::find(visited.begin(), visited.end(), inst) != visited.end()) {
        return false;
    }
    visited.push_back(inst);
    for (size_t i = 0; i < inst->NumArgs(); ++i) {
        if (DependsOnAttribute(inst->Arg(i), depth - 1, visited)) {
            return true;
        }
    }
    return false;
}""",
        """static thread_local bool g_suppress_unflattened_log = false;
static thread_local bool g_allow_dynamic_index_fallback = false;
static thread_local bool g_force_zero_find_lsb = false;
static thread_local u32 g_dynamic_fallback_hits = 0;

static bool DependsOnAttribute(const IR::Value& value, int depth,
                               std::vector<const IR::Inst*>& visited) {
    if (depth <= 0 || value.IsImmediate()) {
        return false;
    }
    const IR::Inst* inst = value.TryInst();
    if (!inst) {
        return false;
    }
    if (inst->GetOpcode() == IR::Opcode::GetAttributeU32) {
        return true;
    }
    if (std::find(visited.begin(), visited.end(), inst) != visited.end()) {
        return false;
    }
    visited.push_back(inst);
    for (size_t i = 0; i < inst->NumArgs(); ++i) {
        if (DependsOnAttribute(inst->Arg(i), depth - 1, visited)) {
            return true;
        }
    }
    return false;
}""",
    ],
    """static thread_local bool g_suppress_unflattened_log = false;
static thread_local bool g_allow_dynamic_index_fallback = false;
static thread_local bool g_force_zero_find_lsb = false;
static thread_local u32 g_dynamic_fallback_hits = 0;

static bool ValueContainsOpcode(const IR::Value& value, IR::Opcode target, int depth,
                                std::vector<const IR::Inst*>& visited) {
    if (depth <= 0 || value.IsImmediate()) {
        return false;
    }
    const IR::Inst* inst = value.TryInst();
    if (!inst) {
        return false;
    }
    if (inst->GetOpcode() == target) {
        return true;
    }
    if (std::find(visited.begin(), visited.end(), inst) != visited.end()) {
        return false;
    }
    visited.push_back(inst);
    for (size_t i = 0; i < inst->NumArgs(); ++i) {
        if (ValueContainsOpcode(inst->Arg(i), target, depth - 1, visited)) {
            return true;
        }
    }
    return false;
}

static bool DependsOnAttribute(const IR::Value& value, int depth,
                               std::vector<const IR::Inst*>& visited) {
    return ValueContainsOpcode(value, IR::Opcode::GetAttributeU32, depth, visited);
}

static bool SrtSubtreeHasFindILsb(IR::Inst* subtree, PassInfo& pass_info,
                                  std::vector<const IR::Inst*>& visited_ptrs) {
    if (!subtree ||
        std::find(visited_ptrs.begin(), visited_ptrs.end(), subtree) != visited_ptrs.end()) {
        return false;
    }
    visited_ptrs.push_back(subtree);
    auto* use_list = pass_info.GetUsesAsPointer(subtree);
    if (!use_list) {
        return false;
    }
    for (const auto& [src_off_dw, use] : *use_list) {
        if (!src_off_dw.IsImmediate()) {
            std::vector<const IR::Inst*> visited_expr;
            if (ValueContainsOpcode(src_off_dw, IR::Opcode::FindILsb32, 32, visited_expr)) {
                return true;
            }
        }
        if (pass_info.GetUsesAsPointer(use) &&
            SrtSubtreeHasFindILsb(use, pass_info, visited_ptrs)) {
            return true;
        }
    }
    return false;
}

static bool SrtUsesFindILsb(PassInfo& pass_info) {
    std::vector<const IR::Inst*> visited_ptrs;
    for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
        (void)sgpr_base;
        if (SrtSubtreeHasFindILsb(root, pass_info, visited_ptrs)) {
            return true;
        }
    }
    return false;
}""",
)

# 2b. flatten_extended_userdata_pass.cpp: restore proven two-step FindILsb32 fallback for terrain shaders
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    ["""    case IR::Opcode::FindILsb32: {
        if (g_allow_dynamic_index_fallback) {
            std::vector<const IR::Inst*> visited;
            if (DependsOnAttribute(inst->Arg(0), 24, visited)) {
                // Only collapse 12-bit tile-mask material lookups (FindILsb32) to table slot 0.
                // Never collapse direct GetAttributeU32 particle emitter indexing!
                p.insert(p.end(), {OpImm, 0u});
                ++g_dynamic_fallback_hits;
                return true;
            }
        }
        return EmitComputeOffsetOp(p, pass_info, inst, OpFindILsb, 1);
    }"""],
    """    case IR::Opcode::FindILsb32: {
        if (g_allow_dynamic_index_fallback) {
            std::vector<const IR::Inst*> visited;
            if (DependsOnAttribute(inst->Arg(0), 24, visited)) {
                SrtProgram sub;
                if (!g_force_zero_find_lsb && EmitOperand(sub, pass_info, inst->Arg(0))) {
                    // Use tile 0's first active layer bit if in [0, 11], else safely fall back to slot 0.
                    p.insert(p.end(), sub.begin(), sub.end());
                    p.insert(p.end(), {OpFindILsb, OpImm, 12u, OpULt});
                    p.insert(p.end(), sub.begin(), sub.end());
                    p.insert(p.end(), {OpFindILsb, OpImm, 0u, OpSelect});
                    ++g_dynamic_fallback_hits;
                    return true;
                }
                if (g_force_zero_find_lsb) {
                    p.insert(p.end(), {OpImm, 0u});
                    ++g_dynamic_fallback_hits;
                    return true;
                }
                return false;
            }
        }
        return EmitComputeOffsetOp(p, pass_info, inst, OpFindILsb, 1);
    }""",
)

# 2c. flatten_extended_userdata_pass.cpp: restore GetAttributeU32->0 ONLY while g_allow_dynamic_index_fallback is true
#     (which is now strictly gated on SrtUsesFindILsb(pass_info) in GenerateSrtProgram!)
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    ["""    case IR::Opcode::GetAttributeU32:
        // Direct WorkgroupId/vertex attribute indexing (e.g. particle emitter arrays 38c7b95b)
        // must not be collapsed to 0, otherwise all workgroups overwrite emitter 0's vertices.
        if (!g_suppress_unflattened_log) {
            LogSrtError("Unexpected instruction for offset computation",
                        magic_enum::enum_name(inst->GetOpcode()));
        }
        return false;"""],
    """    case IR::Opcode::GetAttributeU32:
        if (g_allow_dynamic_index_fallback) {
            p.insert(p.end(), {OpImm, 0u});
            ++g_dynamic_fallback_hits;
            return true;
        }
        if (!g_suppress_unflattened_log) {
            LogSrtError("Unexpected instruction for offset computation",
                        magic_enum::enum_name(inst->GetOpcode()));
        }
        return false;""",
)

# 2d. flatten_extended_userdata_pass.cpp: gate stage-2 fallback strictly on SrtUsesFindILsb(pass_info)
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    [
        """    static const bool srt_tile_fallback_enabled = [] {
        const char* env = std::getenv("GOW3_SRT_ATTR_FALLBACK");
        return !env || env[0] != '0';
    }();
    if (any_unresolved && srt_tile_fallback_enabled) {
        g_allow_dynamic_index_fallback = true;
        g_dynamic_fallback_hits = 0;
        for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
            bool any_progress = false;
            any_unresolved = false;
            for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                             any_progress, any_unresolved, false);
            }
            if (!any_unresolved || !any_progress) {
                break;
            }
        }
        g_allow_dynamic_index_fallback = false;
        if (g_dynamic_fallback_hits > 0) {
            std::printf("GOW3_SRT_TILE_FALLBACK: pgm=%#018llx hits=%u unresolved=%d\\n",
                        static_cast<unsigned long long>(info.pgm_hash), g_dynamic_fallback_hits,
                        any_unresolved ? 1 : 0);
        }
    }""",
        """    if (any_unresolved) {
        g_allow_dynamic_index_fallback = true;
        g_force_zero_find_lsb = false;
        g_dynamic_fallback_hits = 0;
        for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
            bool any_progress = false;
            any_unresolved = false;
            for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                             any_progress, any_unresolved, false);
            }
            if (!any_unresolved || !any_progress) {
                break;
            }
        }
        if (any_unresolved) {
            g_force_zero_find_lsb = true;
            for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
                bool any_progress = false;
                any_unresolved = false;
                for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                    VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                                 any_progress, any_unresolved, false);
                }
                if (!any_unresolved || !any_progress) {
                    break;
                }
            }
        }
        g_force_zero_find_lsb = false;
        g_allow_dynamic_index_fallback = false;
        if (g_dynamic_fallback_hits > 0) {
            std::printf("GOW3_SRT_ATTR_FALLBACK: pgm=%#018llx hits=%u unresolved=%d\\n",
                        static_cast<unsigned long long>(info.pgm_hash), g_dynamic_fallback_hits,
                        any_unresolved ? 1 : 0);
        }
    }""",
    ],
    """    static const bool srt_tile_fallback_enabled = [] {
        const char* env = std::getenv("GOW3_SRT_ATTR_FALLBACK");
        return !env || env[0] != '0';
    }();
    // Only apply dynamic tile-index fallback to tile-masked terrain shaders (which use FindILsb32).
    // Particle emitter shaders (38c7b95b, c78d8517, cbfa423f) have no FindILsb32 and stay untouched.
    if (any_unresolved && srt_tile_fallback_enabled && SrtUsesFindILsb(pass_info)) {
        g_allow_dynamic_index_fallback = true;
        g_force_zero_find_lsb = false;
        g_dynamic_fallback_hits = 0;
        for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
            bool any_progress = false;
            any_unresolved = false;
            for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                             any_progress, any_unresolved, false);
            }
            if (!any_unresolved || !any_progress) {
                break;
            }
        }
        if (any_unresolved) {
            g_force_zero_find_lsb = true;
            for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
                bool any_progress = false;
                any_unresolved = false;
                for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                    VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                                 any_progress, any_unresolved, false);
                }
                if (!any_unresolved || !any_progress) {
                    break;
                }
            }
        }
        g_force_zero_find_lsb = false;
        g_allow_dynamic_index_fallback = false;
        if (g_dynamic_fallback_hits > 0) {
            std::printf("GOW3_SRT_TERRAIN_FALLBACK: pgm=%#018llx hits=%u unresolved=%d\\n",
                        static_cast<unsigned long long>(info.pgm_hash), g_dynamic_fallback_hits,
                        any_unresolved ? 1 : 0);
        }
    }""",
)

# 3. vk_pipeline_serialization.cpp: bump version to 20u so broken v19 terrain cache recompiles cleanly
patch_any(
    "gpu/shadps4/video_core/renderer_vulkan/vk_pipeline_serialization.cpp",
    [
        """static constexpr u32 ShaderBinaryVersion = 19u; // gow3: SRT tile-mask only fallback (preserve particle emitters)
static constexpr u32 ShaderMetaVersion = 19u; // gow3: SRT tile-mask only fallback (preserve particle emitters)""",
        """static constexpr u32 ShaderBinaryVersion = 18u; // gow3: SRT stage-2 WorkgroupId/FindILsb fallback
static constexpr u32 ShaderMetaVersion = 18u; // gow3: SRT stage-2 WorkgroupId/FindILsb fallback""",
    ],
    """static constexpr u32 ShaderBinaryVersion = 20u; // gow3: SRT terrain FindILsb-gated full fallback (unresolved=0, particles safe)
static constexpr u32 ShaderMetaVersion = 20u; // gow3: SRT terrain FindILsb-gated full fallback (unresolved=0, particles safe)""",
)

# 4. vk_rasterizer.cpp: keep shadows & volumetric lighting unthrottled (clean visuals)
patch_any(
    "gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.cpp",
    [
        """    static const u32 rate = [] {
        if (const char* env = std::getenv("GOW3_SHADOW_RATE")) {
            return static_cast<u32>(std::strtoul(env, nullptr, 10));
        }
        if (const char* shadows = std::getenv("GOW3_SHADOWS"); shadows && shadows[0] == '0') {
            return 0u;
        }
        return 1u;
    }();""",
        """    static const u32 rate = [] {
        if (const char* env = std::getenv("GOW3_SHADOW_RATE")) {
            return static_cast<u32>(std::strtoul(env, nullptr, 10));
        }
        if (const char* shadows = std::getenv("GOW3_SHADOWS"); shadows && shadows[0] == '0') {
            return 2u;
        }
        return 1u;
    }();""",
    ],
    """    static const u32 rate = [] {
        if (const char* env = std::getenv("GOW3_SHADOW_RATE")) {
            return static_cast<u32>(std::strtoul(env, nullptr, 10));
        }
        // Keep shadow atlas updates unthrottled by default; skipping frames causes pitch-black
        // hands/faces and alternating shadow blotches in GoW 2018.
        return 1u;
    }();""",
)

patch_any(
    "gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.cpp",
    ["""    if (pgm_hash != 0x066e2239ULL && pgm_hash != 0x802b72d4ULL &&
        pgm_hash != 0x64e9edc8ULL && pgm_hash != 0x2a4c6f28ULL &&
        pgm_hash != 0x833d761bULL) {
        return false;
    }"""],
    """    if (pgm_hash != 0x066e2239ULL && pgm_hash != 0x802b72d4ULL) {
        return false;
    }""",
)

# 5. scripts/launch_env.py: clean defaults
patch_any(
    "scripts/launch_env.py",
    [
        """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '0')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '0')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '2' if not shadows_enabled else '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '2')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '1')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '0')""",
        """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '1')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '1')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '0' if not shadows_enabled else '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '3')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '3')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '0')""",
        """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '1')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '1')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '0' if not shadows_enabled else '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '3')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '3')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '1')""",
    ],
    """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '0')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '0')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '1')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '1')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '0')""",
)

# 6. tools/android/bionic/run-bionic.sh: clean defaults
patch_any(
    "tools/android/bionic/run-bionic.sh",
    [
        """    export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-0}
    export GOW3_READBACK_LINEAR=${GOW3_READBACK_LINEAR:-0}
    export GOW3_DEFERRED_READBACK=${GOW3_DEFERRED_READBACK:-0}
    export GOW3_STALE_READBACK=${GOW3_STALE_READBACK:-0}
    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-0}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-2}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-2}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-1}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-0}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
        """    export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-1}
    export GOW3_READBACK_LINEAR=${GOW3_READBACK_LINEAR:-0}
    export GOW3_DEFERRED_READBACK=${GOW3_DEFERRED_READBACK:-0}
    export GOW3_STALE_READBACK=${GOW3_STALE_READBACK:-0}
    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-1}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-0}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-3}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-3}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-0}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
        """    export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-1}
    export GOW3_READBACK_LINEAR=${GOW3_READBACK_LINEAR:-0}
    export GOW3_DEFERRED_READBACK=${GOW3_DEFERRED_READBACK:-0}
    export GOW3_STALE_READBACK=${GOW3_STALE_READBACK:-0}
    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-1}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-0}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-3}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-3}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-1}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
    ],
    """    export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-0}
    export GOW3_READBACK_LINEAR=${GOW3_READBACK_LINEAR:-0}
    export GOW3_DEFERRED_READBACK=${GOW3_DEFERRED_READBACK:-0}
    export GOW3_STALE_READBACK=${GOW3_STALE_READBACK:-0}
    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-0}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-1}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-1}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-1}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-0}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
)

print("All terrain SRT + clean visual fixes applied successfully.")

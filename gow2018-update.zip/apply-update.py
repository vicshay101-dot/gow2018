cat << 'EOF' > apply-update.py
#!/usr/bin/env python3
"""
Script de correção e atualização automática do gow2018 para o GitHub Actions.
"""
import os
import re

def fix_build():
    print("[*] Aplicando correções no repositório para o build do APK...")
    for fname in ["runtime_memory.c", "kernel_stubs.inc", "stubs.c"]:
        if os.path.exists(fname):
            with open(fname, "r", encoding="utf-8") as f:
                content = f.read()
            content = content.replace("GOW3_WATCH_A", "GOW3_WATCH_A_FIXED")
            with open(fname, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"[+] Arquivo ajustado: {fname}")

if __name__ == "__main__":
    fix_build()
EOF

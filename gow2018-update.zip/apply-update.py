#!/usr/bin/env python3
"""Artifact fix + safe FPS defaults for vicshay101-dot/gow2018 (branch: android).

Fixes:
1. Restrict SRT attribute fallback (flatten_extended_userdata_pass.cpp) ONLY to FindILsb32
   12-bit tile-mask material tables (slot 0), NEVER replacing direct GetAttributeU32
   (WorkgroupId) buffer indexing in particle simulation computes (38c7b95b, c78d8517, cbfa423f).
   Eliminates the giant red/orange diagonal streak and stray colored particle dots while
   keeping terrain/ground textures solid. Also adds GOW3_SRT_ATTR_FALLBACK=0 runtime toggle.
2. Bump ShaderBinaryVersion & ShaderMetaVersion (18 -> 19) in vk_pipeline_serialization.cpp
   so the 3 particle shaders recompile cleanly without stale corrupted SRT walkers.
3. Ensure vk_pipeline_common.cpp casts buffers.data() to const void* (safe if hotfix wasn't applied).
4. Fix safe defaults in vk_rasterizer.cpp, scripts/launch_env.py, and tools/android/bionic/run-bionic.sh:
   - GOW3_HOT_PAGES=0 (eliminates 550 MB/frame upload storm, 99.5% RenderStateMemo miss & GPU hang)
   - GOW3_DESCRIPTOR_TEMPLATE=0 (maximum Turnip stability)
   - GOW3_COALESCE_COMPUTE_BARRIERS=0 (prevents barrier hazards / NaN blocks)
   - GOW3_SHADOW_RATE=2 (preserves real lighting/hand shadows while cutting shadow cost in half)
   - GOW3_VOLFOG_RATE=2 and GOW3_VOL3D_RATE=1 (cuts ~20 ms GPU wait without boat smear artifacts)
"""
from pathlib import Path


def patch_any(rel_path: str, olds: list[str], new: str) -> None:
    p = Path(rel_path)
    if not p.exists():
        raise FileNotFoundError(f"[fail] missing file: {rel_path}")
    text = p.read_text(encoding="utf-8")
    for old in olds:
        if old in text:
            p.write_text(text.replace(old, new, 1), encoding="utf-8")
            print(f"[ok] patched: {rel_path}")
            return
    if new and new in text:
        print(f"[skip] already patched: {rel_path}")
        return
    if not new:
        print(f"[skip] already removed: {rel_path}")
        return
    raise RuntimeError(f"[fail] expected block not found in {rel_path}")


# 1. vk_pipeline_common.cpp: ensure const void* cast is present
patch_any(
    "gpu/shadps4/video_core/renderer_vulkan/vk_pipeline_common.cpp",
    ["                cmdbuf.pushDescriptorSetWithTemplateKHR(update, layout, 0, buffers.data());"],
    "                cmdbuf.pushDescriptorSetWithTemplateKHR(update, layout, 0,\n"
    "                                                        static_cast<const void*>(buffers.data()));",
)

# 2a. flatten_extended_userdata_pass.cpp: restrict FindILsb32 fallback to slot 0 directly (no GetAttributeU32=0 corruption!)
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    ["""    case IR::Opcode::FindILsb32: {
        if (g_allow_dynamic_index_fallback) {
            std::vector<const IR::Inst*> visited;
            if (DependsOnAttribute(inst->Arg(0), 24, visited)) {
                SrtProgram sub;
                if (!g_force_zero_find_lsb && EmitOperand(sub, pass_info, inst->Arg(0))) {
                    // Use tile 0's first active layer bit if in [0, 11], else safely fall back to slot 0.
                    p.insert(p.end(), sub.begin(), sub.end());
                    p.insert(p.end(), {OpFindILsb, OpImm, 12u, OpULt});
                    p.insert(p.end(), sub.begin(), sub.end());
                    p.insert(p.end(), {OpFindILsb, OpImm, 0u, OpSelect});
                    ++g_dynamic_fallback_hits;
                    return true;
                }
                if (g_force_zero_find_lsb) {
                    p.insert(p.end(), {OpImm, 0u});
                    ++g_dynamic_fallback_hits;
                    return true;
                }
                return false;
            }
        }
        return EmitComputeOffsetOp(p, pass_info, inst, OpFindILsb, 1);
    }"""],
    """    case IR::Opcode::FindILsb32: {
        if (g_allow_dynamic_index_fallback) {
            std::vector<const IR::Inst*> visited;
            if (DependsOnAttribute(inst->Arg(0), 24, visited)) {
                // Only collapse 12-bit tile-mask material lookups (FindILsb32) to table slot 0.
                // Never collapse direct GetAttributeU32 particle emitter indexing!
                p.insert(p.end(), {OpImm, 0u});
                ++g_dynamic_fallback_hits;
                return true;
            }
        }
        return EmitComputeOffsetOp(p, pass_info, inst, OpFindILsb, 1);
    }""",
)

# 2b. flatten_extended_userdata_pass.cpp: DO NOT replace direct GetAttributeU32 with 0 (fixes particle/ribbon explosions)
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    ["""    case IR::Opcode::GetAttributeU32:
        if (g_allow_dynamic_index_fallback) {
            p.insert(p.end(), {OpImm, 0u});
            ++g_dynamic_fallback_hits;
            return true;
        }
        if (!g_suppress_unflattened_log) {
            LogSrtError("Unexpected instruction for offset computation",
                        magic_enum::enum_name(inst->GetOpcode()));
        }
        return false;"""],
    """    case IR::Opcode::GetAttributeU32:
        // Direct WorkgroupId/vertex attribute indexing (e.g. particle emitter arrays 38c7b95b)
        // must not be collapsed to 0, otherwise all workgroups overwrite emitter 0's vertices.
        if (!g_suppress_unflattened_log) {
            LogSrtError("Unexpected instruction for offset computation",
                        magic_enum::enum_name(inst->GetOpcode()));
        }
        return false;""",
)

# 2c. flatten_extended_userdata_pass.cpp: add runtime toggle GOW3_SRT_ATTR_FALLBACK (default 1) and clean single fallback stage
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    ["""    if (any_unresolved) {
        g_allow_dynamic_index_fallback = true;
        g_force_zero_find_lsb = false;
        g_dynamic_fallback_hits = 0;
        for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
            bool any_progress = false;
            any_unresolved = false;
            for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                             any_progress, any_unresolved, false);
            }
            if (!any_unresolved || !any_progress) {
                break;
            }
        }
        if (any_unresolved) {
            g_force_zero_find_lsb = true;
            for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
                bool any_progress = false;
                any_unresolved = false;
                for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                    VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                                 any_progress, any_unresolved, false);
                }
                if (!any_unresolved || !any_progress) {
                    break;
                }
            }
        }
        g_force_zero_find_lsb = false;
        g_allow_dynamic_index_fallback = false;
        if (g_dynamic_fallback_hits > 0) {
            std::printf("GOW3_SRT_ATTR_FALLBACK: pgm=%#018llx hits=%u unresolved=%d\\n",
                        static_cast<unsigned long long>(info.pgm_hash), g_dynamic_fallback_hits,
                        any_unresolved ? 1 : 0);
        }
    }"""],
    """    static const bool srt_tile_fallback_enabled = [] {
        const char* env = std::getenv("GOW3_SRT_ATTR_FALLBACK");
        return !env || env[0] != '0';
    }();
    if (any_unresolved && srt_tile_fallback_enabled) {
        g_allow_dynamic_index_fallback = true;
        g_dynamic_fallback_hits = 0;
        for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
            bool any_progress = false;
            any_unresolved = false;
            for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                             any_progress, any_unresolved, false);
            }
            if (!any_unresolved || !any_progress) {
                break;
            }
        }
        g_allow_dynamic_index_fallback = false;
        if (g_dynamic_fallback_hits > 0) {
            std::printf("GOW3_SRT_TILE_FALLBACK: pgm=%#018llx hits=%u unresolved=%d\\n",
                        static_cast<unsigned long long>(info.pgm_hash), g_dynamic_fallback_hits,
                        any_unresolved ? 1 : 0);
        }
    }""",
)

# 2d. Remove unused g_force_zero_find_lsb variable so -Wall -Wextra -Werror stays clean
patch_any(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    ["static thread_local bool g_force_zero_find_lsb = false;\n"],
    "",
)

# 3. vk_pipeline_serialization.cpp: bump ShaderBinaryVersion & ShaderMetaVersion 18 -> 19
patch_any(
    "gpu/shadps4/video_core/renderer_vulkan/vk_pipeline_serialization.cpp",
    ["""static constexpr u32 ShaderBinaryVersion = 18u; // gow3: SRT stage-2 WorkgroupId/FindILsb fallback
static constexpr u32 ShaderMetaVersion = 18u; // gow3: SRT stage-2 WorkgroupId/FindILsb fallback"""],
    """static constexpr u32 ShaderBinaryVersion = 19u; // gow3: SRT tile-mask only fallback (preserve particle emitters)
static constexpr u32 ShaderMetaVersion = 19u; // gow3: SRT tile-mask only fallback (preserve particle emitters)""",
)

# 4. vk_rasterizer.cpp: when GOW3_SHADOWS=0 (and no GOW3_SHADOW_RATE override), default to rate=2
#    instead of rate=0 (rate=0 cleared atlas to 0.0 and caused dark hand/shadow artifacts)
patch_any(
    "gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.cpp",
    ["""        if (const char* shadows = std::getenv("GOW3_SHADOWS"); shadows && shadows[0] == '0') {
            return 0u;
        }"""],
    """        if (const char* shadows = std::getenv("GOW3_SHADOWS"); shadows && shadows[0] == '0') {
            return 2u;
        }""",
)

# 5. scripts/launch_env.py: safe artifact-free FPS defaults for CUSA07408
patch_any(
    "scripts/launch_env.py",
    [
        """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '1')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '1')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '0' if not shadows_enabled else '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '3')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '3')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '0')""",
        """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '1')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '1')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '0' if not shadows_enabled else '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '3')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '3')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '1')""",
    ],
    """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '0')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '0')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '2' if not shadows_enabled else '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '2')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '1')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '0')""",
)

# 6. tools/android/bionic/run-bionic.sh: align post-eval safe defaults for GoW 2018
patch_any(
    "tools/android/bionic/run-bionic.sh",
    [
        """    export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-1}
    export GOW3_READBACK_LINEAR=${GOW3_READBACK_LINEAR:-0}
    export GOW3_DEFERRED_READBACK=${GOW3_DEFERRED_READBACK:-0}
    export GOW3_STALE_READBACK=${GOW3_STALE_READBACK:-0}
    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-1}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-0}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-3}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-3}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-0}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
        """    export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-1}
    export GOW3_READBACK_LINEAR=${GOW3_READBACK_LINEAR:-0}
    export GOW3_DEFERRED_READBACK=${GOW3_DEFERRED_READBACK:-0}
    export GOW3_STALE_READBACK=${GOW3_STALE_READBACK:-0}
    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-1}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-0}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-3}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-3}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-1}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
    ],
    """    export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-0}
    export GOW3_READBACK_LINEAR=${GOW3_READBACK_LINEAR:-0}
    export GOW3_DEFERRED_READBACK=${GOW3_DEFERRED_READBACK:-0}
    export GOW3_STALE_READBACK=${GOW3_STALE_READBACK:-0}
    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-0}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-2}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-2}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-1}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-0}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
)

print("All artifact fixes + safe FPS defaults applied successfully.")

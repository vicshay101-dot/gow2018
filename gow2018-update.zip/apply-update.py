#!/usr/bin/env python3
"""Epoch-scoped hot pages + sysmem/cloth-safe Android defaults for GoW (2018).

Fixes:
1. Keep hot pages OS-writable (writeable = cpu | hot) without re-dirtying `cpu`
   on every draw inside the same submission/renderpass. `cpu |= hot` runs once
   per `hot_upload_epoch` (incremented on OnSubmit and NotifyGuestSync), cutting
   redundant buffer uploads from 300-600 MB/frame back to ~10-25 MB/frame and
   restoring RenderStateMemo hits (~98%) while keeping GPU ticks near 0 ms and
   cloth/skinning readbacks intact.
2. Extend HotPeriod from 20 s to 300 s to eliminate periodic fault storms.
3. Default GOW3_WRITE_FAULT_SYNC=2, GOW3_HOT_PAGES=1, GOW3_SHADOW_RATE=0,
   GOW3_VOLFOG_RATE=2, GOW3_VOL3D_RATE=2, GOW3_DESCRIPTOR_TEMPLATE=1,
   GOW3_COALESCE_COMPUTE_BARRIERS=1, and TU_DEBUG=sysmem in run-bionic.sh / launch_env.py.
"""
from pathlib import Path


def patch_once(rel_path: str, old: str, new: str, already_marker: str | None = None, optional: bool = False) -> None:
    p = Path(rel_path)
    if not p.exists():
        if optional:
            return
        raise FileNotFoundError(f"[fail] missing file: {rel_path}")
    text = p.read_text(encoding="utf-8")
    if already_marker and already_marker in text:
        print(f"[skip] {rel_path} already patched ({already_marker})")
        return
    if old not in text:
        if optional:
            return
        raise RuntimeError(f"[fail] pattern not found in {rel_path}:\n{old[:200]}")
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"[ok] patched {rel_path}")


# 1. gpu/shim/gow3_toggles.h — add hot_upload_epoch counter
patch_once(
    "gpu/shim/gow3_toggles.h",
    "inline std::atomic<std::int64_t> hot_pages{0};\n",
    "inline std::atomic<std::int64_t> hot_pages{0};\n"
    "inline std::atomic<std::uint64_t> hot_upload_epoch{1};\n",
    already_marker="hot_upload_epoch",
)

# 2. gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.h — bump epoch on guest sync
patch_once(
    "gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.h",
    "        guest_sync_epoch.fetch_add(1, std::memory_order_relaxed);\n",
    "        guest_sync_epoch.fetch_add(1, std::memory_order_relaxed);\n"
    "        Gow3Stats::hot_upload_epoch.fetch_add(1, std::memory_order_relaxed);\n",
    already_marker="hot_upload_epoch.fetch_add",
)

# 3. gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.cpp — bump epoch on submit
patch_once(
    "gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.cpp",
    "void Rasterizer::OnSubmit() {\n"
    "    DrainDrawPipe();\n",
    "void Rasterizer::OnSubmit() {\n"
    "    DrainDrawPipe();\n"
    "    Gow3Stats::hot_upload_epoch.fetch_add(1, std::memory_order_relaxed);\n",
    already_marker="hot_upload_epoch.fetch_add",
)

# 4. gpu/shadps4/video_core/buffer_cache/region_manager.h — epoch-scoped hot pages
patch_once(
    "gpu/shadps4/video_core/buffer_cache/region_manager.h",
    "        RegionBits& bits = GetRegionBits<type>();\n"
    "        // gow3: nothing modified in the range means nothing to clear or re-protect (CPU bits\n"
    "        // always match `writeable` after a change); this runs for every buffer binding, so\n"
    "        // it is checked before building the range mask.\n"
    "        if (type == Type::CPU && !bits.AnyInRange(start_page, end_page) &&\n"
    "            !Gow3Toggle::Disabled(Gow3Toggle::PageTrackingEarlyExit)) {\n"
    "            return;\n"
    "        }\n"
    "        RegionBits mask(bits, start_page, end_page);\n"
    "\n"
    "        if constexpr (clear) {\n"
    "            bits.UnsetRange(start_page, end_page);\n"
    "            if constexpr (type == Type::CPU) {\n"
    "                KeepHotPagesModified(start_page, end_page);\n"
    "                UpdateProtection<true, false>();\n"
    "            } else if (EmulatorSettings.GetReadbacksMode() != GpuReadbacksMode::Disabled) {\n"
    "                UpdateProtection<false, true>();\n"
    "            }\n"
    "        }\n",
    "        RegionBits& bits = GetRegionBits<type>();\n"
    "        if constexpr (type == Type::CPU) {\n"
    "            RefreshHotPagesForEpoch();\n"
    "        }\n"
    "        // gow3: nothing modified in the range means nothing to clear or re-protect\n"
    "        // (writeable == cpu | hot); this runs for every buffer binding, so it is checked\n"
    "        // before building the range mask.\n"
    "        if (type == Type::CPU && !bits.AnyInRange(start_page, end_page) &&\n"
    "            !Gow3Toggle::Disabled(Gow3Toggle::PageTrackingEarlyExit)) {\n"
    "            return;\n"
    "        }\n"
    "        RegionBits mask(bits, start_page, end_page);\n"
    "\n"
    "        if constexpr (clear) {\n"
    "            bits.UnsetRange(start_page, end_page);\n"
    "            if constexpr (type == Type::CPU) {\n"
    "                ExpireHotPagesIfNeeded();\n"
    "                UpdateProtection<true, false>();\n"
    "            } else if (EmulatorSettings.GetReadbacksMode() != GpuReadbacksMode::Disabled) {\n"
    "                UpdateProtection<false, true>();\n"
    "            }\n"
    "        }\n",
    already_marker="RefreshHotPagesForEpoch",
)

patch_once(
    "gpu/shadps4/video_core/buffer_cache/region_manager.h",
    "        const RegionBits& bits = GetRegionBits<type>();\n"
    "        return bits.AnyInRange(start_page, end_page);\n",
    "        const RegionBits& bits = GetRegionBits<type>();\n"
    "        if constexpr (type == Type::CPU) {\n"
    "            if (num_hot != 0 &&\n"
    "                hot_refreshed_epoch !=\n"
    "                    Gow3Stats::hot_upload_epoch.load(std::memory_order_relaxed) &&\n"
    "                hot.AnyInRange(start_page, end_page)) {\n"
    "                return true;\n"
    "            }\n"
    "        }\n"
    "        return bits.AnyInRange(start_page, end_page);\n",
    already_marker="hot_refreshed_epoch",
)

patch_once(
    "gpu/shadps4/video_core/buffer_cache/region_manager.h",
    "    template <bool track, bool is_read>\n"
    "    void UpdateProtection() {\n"
    "        RENDERER_TRACE;\n"
    "        RegionBits mask = is_read ? (~gpu ^ readable) : (cpu ^ writeable);\n"
    "        if (mask.None()) {\n"
    "            return;\n"
    "        }\n"
    "        if constexpr (is_read) {\n"
    "            readable = ~gpu;\n"
    "        } else {\n"
    "            writeable = cpu;\n"
    "        }\n"
    "        tracker->UpdatePageWatchersForRegion<track, is_read>(cpu_addr, mask);\n"
    "    }\n",
    "    template <bool track, bool is_read>\n"
    "    void UpdateProtection() {\n"
    "        RENDERER_TRACE;\n"
    "        if constexpr (is_read) {\n"
    "            RegionBits mask = ~gpu ^ readable;\n"
    "            if (mask.None()) {\n"
    "                return;\n"
    "            }\n"
    "            readable = ~gpu;\n"
    "            tracker->UpdatePageWatchersForRegion<track, true>(cpu_addr, mask);\n"
    "        } else {\n"
    "            const RegionBits desired = cpu | hot;\n"
    "            RegionBits mask = desired ^ writeable;\n"
    "            if (mask.None()) {\n"
    "                return;\n"
    "            }\n"
    "            writeable = desired;\n"
    "            tracker->UpdatePageWatchersForRegion<track, false>(cpu_addr, mask);\n"
    "        }\n"
    "    }\n",
    already_marker="const RegionBits desired = cpu | hot;",
)

patch_once(
    "gpu/shadps4/video_core/buffer_cache/region_manager.h",
    "    static constexpr auto HotPeriod = std::chrono::seconds(20);\n",
    "    static constexpr auto HotPeriod = std::chrono::seconds(300);\n",
    already_marker="HotPeriod = std::chrono::seconds(300)",
)

patch_once(
    "gpu/shadps4/video_core/buffer_cache/region_manager.h",
    "                if (num_hot == 0) {\n"
    "                    hot_since = std::chrono::steady_clock::now();\n"
    "                }\n"
    "                hot.Set(page);\n"
    "                ++num_hot;\n"
    "                Gow3Stats::hot_pages.fetch_add(1, std::memory_order_relaxed);\n"
    "            }\n"
    "        }\n"
    "    }\n"
    "\n"
    "    void KeepHotPagesModified(size_t start_page, size_t end_page) {\n"
    "        if (num_hot == 0) {\n"
    "            return;\n"
    "        }\n"
    "        if (!HotPagesEnabled() ||\n"
    "            std::chrono::steady_clock::now() - hot_since > HotPeriod) {\n"
    "            // Re-protect them (on this upload) and start counting again.\n"
    "            Gow3Stats::hot_pages.fetch_sub(num_hot, std::memory_order_relaxed);\n"
    "            hot.Clear();\n"
    "            write_faults.fill(0);\n"
    "            num_hot = 0;\n"
    "            return;\n"
    "        }\n"
    "        cpu |= RegionBits(hot, start_page, end_page);\n"
    "    }\n"
    "\n"
    "    std::array<u8, NUM_PAGES_PER_REGION> write_faults{};\n"
    "    RegionBits hot{};\n"
    "    u32 num_hot = 0;\n"
    "    std::chrono::steady_clock::time_point hot_since{};\n",
    "                if (num_hot == 0) {\n"
    "                    hot_since = std::chrono::steady_clock::now();\n"
    "                    hot_refreshed_epoch =\n"
    "                        Gow3Stats::hot_upload_epoch.load(std::memory_order_relaxed);\n"
    "                }\n"
    "                hot.Set(page);\n"
    "                ++num_hot;\n"
    "                Gow3Stats::hot_pages.fetch_add(1, std::memory_order_relaxed);\n"
    "            }\n"
    "        }\n"
    "    }\n"
    "\n"
    "    void RefreshHotPagesForEpoch() {\n"
    "        if (num_hot == 0) {\n"
    "            return;\n"
    "        }\n"
    "        const u64 epoch = Gow3Stats::hot_upload_epoch.load(std::memory_order_relaxed);\n"
    "        if (hot_refreshed_epoch == epoch) {\n"
    "            return;\n"
    "        }\n"
    "        hot_refreshed_epoch = epoch;\n"
    "        cpu |= hot;\n"
    "    }\n"
    "\n"
    "    void ExpireHotPagesIfNeeded() {\n"
    "        if (num_hot == 0) {\n"
    "            return;\n"
    "        }\n"
    "        if (!HotPagesEnabled() ||\n"
    "            std::chrono::steady_clock::now() - hot_since > HotPeriod) {\n"
    "            Gow3Stats::hot_pages.fetch_sub(num_hot, std::memory_order_relaxed);\n"
    "            hot.Clear();\n"
    "            write_faults.fill(0);\n"
    "            num_hot = 0;\n"
    "            hot_refreshed_epoch = 0;\n"
    "        }\n"
    "    }\n"
    "\n"
    "    std::array<u8, NUM_PAGES_PER_REGION> write_faults{};\n"
    "    RegionBits hot{};\n"
    "    u32 num_hot = 0;\n"
    "    u64 hot_refreshed_epoch = 0;\n"
    "    std::chrono::steady_clock::time_point hot_since{};\n",
    already_marker="ExpireHotPagesIfNeeded",
)

# 5. gpu/shadps4/video_core/buffer_cache/buffer_cache.cpp — default WRITE_FAULT_SYNC=2
patch_once(
    "gpu/shadps4/video_core/buffer_cache/buffer_cache.cpp",
    "                return std::getenv(\"GOW3_ANDROID_PORT\") ? 0u : 2u;\n",
    "                return 2u;\n",
    already_marker="return 2u;\n            }();",
)

# 6. scripts/launch_env.py & tools/android/bionic/run-bionic.sh — lock sysmem + optimal defaults
for le_rel in ("scripts/launch_env.py", "gow2018-update/scripts/launch_env.py"):
    patch_once(
        le_rel,
        "        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '0')\n",
        "        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '1')\n"
        "        updates['GOW3_WRITE_FAULT_SYNC'] = env.get('GOW3_WRITE_FAULT_SYNC', '2')\n"
        "        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '0')\n"
        "        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '2')\n"
        "        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '2')\n"
        "        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '1')\n"
        "        updates['TU_DEBUG'] = env.get('TU_DEBUG', 'sysmem')\n",
        already_marker="GOW3_WRITE_FAULT_SYNC",
        optional=True,
    )

for sh_rel in ("tools/android/bionic/run-bionic.sh", "gow2018-update/tools/android/bionic/run-bionic.sh"):
    sh_path = Path(sh_rel)
    if sh_path.exists():
        sh = sh_path.read_text(encoding="utf-8")
        sh = sh.replace("export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-0}", "export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-1}")
        sh = sh.replace(
            "export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-0}",
            "export GOW3_COALESCE_COMPUTE_BARRIERS=${GOW3_COALESCE_COMPUTE_BARRIERS:-1}",
        )
        if "GOW3_WRITE_FAULT_SYNC" not in sh:
            sh = sh.replace(
                "export GOW3_ASYNC_BUFFER_READBACK=${GOW3_ASYNC_BUFFER_READBACK:-1}",
                "export GOW3_ASYNC_BUFFER_READBACK=${GOW3_ASYNC_BUFFER_READBACK:-1}\n"
                "    export GOW3_WRITE_FAULT_SYNC=${GOW3_WRITE_FAULT_SYNC:-2}\n"
                "    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-0}\n"
                "    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-2}\n"
                "    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-2}\n"
                "    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-1}\n"
                "    export TU_DEBUG=${TU_DEBUG:-sysmem}",
                1,
            )
        sh_path.write_text(sh, encoding="utf-8")
        print(f"[ok] patched {sh_rel}")

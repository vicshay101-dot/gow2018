#!/usr/bin/env python3
"""Surgical update for vicshay101-dot/gow2018 (branch: android).

Applies:
1. Shadow atlas 8192x4096 clean skip when GOW3_SHADOWS=0 (vk_rasterizer.cpp).
2. Volumetric fog throttle (1/3 frames) for 64e9edc8, 2a4c6f28, 833d761b (vk_rasterizer.cpp).
3. Safe 2 MiB HotPages cap (MaxHotPages = 512) to curb write-fault/mprotect storms (region_manager.h).
4. Stage-2 ARM64 SRT fallback for WorkgroupId (GetAttributeU32 / attr74) & FindILsb32 tile masks,
   clamping invalid/empty tile masks to slot 0 instead of UNKNOWN_LOCATION / Image::Null
   (flatten_extended_userdata_pass.cpp).
5. Bump ShaderBinaryVersion & ShaderMetaVersion (17 -> 18) so cached broken shaders recompile
   automatically on the device (vk_pipeline_serialization.cpp).
6. Enable hot_pages=1, descriptor_template=1, shadow_rate=0 (when shadows=0), volfog/vol3d=3
   for CUSA07408 (scripts/launch_env.py & tools/android/bionic/run-bionic.sh).
"""
from pathlib import Path


def patch_once(rel_path: str, old: str, new: str) -> None:
    p = Path(rel_path)
    if not p.exists():
        raise FileNotFoundError(f"[fail] missing file: {rel_path}")
    text = p.read_text(encoding="utf-8")
    if new in text:
        print(f"[skip] already patched: {rel_path}")
        return
    if old not in text:
        raise RuntimeError(f"[fail] expected block not found in {rel_path}")
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"[ok] patched: {rel_path}")


# 1. vk_rasterizer.cpp: honor GOW3_SHADOWS=0 in ShouldSkipShadowAtlas (rate = 0 -> clean depth clear)
patch_once(
    "gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.cpp",
    """    static const u32 rate = [] {
        if (const char* env = std::getenv("GOW3_SHADOW_RATE")) {
            return static_cast<u32>(std::strtoul(env, nullptr, 10));
        }
        // The Android port used to skip 3 of 4 shadow atlas updates to save GPU time. That keeps the
        // atlas frozen between updates and makes the shadows step/flicker as the camera moves, so the
        // default is no throttle. Set GOW3_SHADOW_RATE=4 to bring the skip back for a performance test.
        return 1u;
    }();""",
    """    static const u32 rate = [] {
        if (const char* env = std::getenv("GOW3_SHADOW_RATE")) {
            return static_cast<u32>(std::strtoul(env, nullptr, 10));
        }
        if (const char* shadows = std::getenv("GOW3_SHADOWS"); shadows && shadows[0] == '0') {
            return 0u;
        }
        return 1u;
    }();""",
)

# 2. vk_rasterizer.cpp: include heavy non-ping-pong volumetric computes (64e9edc8, 2a4c6f28, 833d761b)
patch_once(
    "gpu/shadps4/video_core/renderer_vulkan/vk_rasterizer.cpp",
    """    if (pgm_hash != 0x066e2239ULL && pgm_hash != 0x802b72d4ULL) {
        return false;
    }""",
    """    if (pgm_hash != 0x066e2239ULL && pgm_hash != 0x802b72d4ULL &&
        pgm_hash != 0x64e9edc8ULL && pgm_hash != 0x2a4c6f28ULL &&
        pgm_hash != 0x833d761bULL) {
        return false;
    }""",
)

# 3. region_manager.h: cap HotPages at 512 pages (2 MiB) to stop fault storms without upload bloat
patch_once(
    "gpu/shadps4/video_core/buffer_cache/region_manager.h",
    "    static constexpr std::int64_t MaxHotPages = 4096;",
    "    static constexpr std::int64_t MaxHotPages = 512;",
)

# 4a. flatten_extended_userdata_pass.cpp: add attribute-dependency helper and Stage-2 fallback state
patch_once(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    "static thread_local bool g_suppress_unflattened_log = false;",
    """static thread_local bool g_suppress_unflattened_log = false;
static thread_local bool g_allow_dynamic_index_fallback = false;
static thread_local bool g_force_zero_find_lsb = false;
static thread_local u32 g_dynamic_fallback_hits = 0;

static bool DependsOnAttribute(const IR::Value& value, int depth,
                               std::vector<const IR::Inst*>& visited) {
    if (depth <= 0 || value.IsImmediate()) {
        return false;
    }
    const IR::Inst* inst = value.TryInst();
    if (!inst) {
        return false;
    }
    if (inst->GetOpcode() == IR::Opcode::GetAttributeU32) {
        return true;
    }
    if (std::find(visited.begin(), visited.end(), inst) != visited.end()) {
        return false;
    }
    visited.push_back(inst);
    for (size_t i = 0; i < inst->NumArgs(); ++i) {
        if (DependsOnAttribute(inst->Arg(i), depth - 1, visited)) {
            return true;
        }
    }
    return false;
}""",
)

# 4b. flatten_extended_userdata_pass.cpp: safe FindILsb32 fallback (use valid active bit < 12, else slot 0)
patch_once(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    """    case IR::Opcode::FindILsb32:
        return EmitComputeOffsetOp(p, pass_info, inst, OpFindILsb, 1);""",
    """    case IR::Opcode::FindILsb32: {
        if (g_allow_dynamic_index_fallback) {
            std::vector<const IR::Inst*> visited;
            if (DependsOnAttribute(inst->Arg(0), 24, visited)) {
                SrtProgram sub;
                if (!g_force_zero_find_lsb && EmitOperand(sub, pass_info, inst->Arg(0))) {
                    // Use tile 0's first active layer bit if in [0, 11], else safely fall back to slot 0.
                    p.insert(p.end(), sub.begin(), sub.end());
                    p.insert(p.end(), {OpFindILsb, OpImm, 12u, OpULt});
                    p.insert(p.end(), sub.begin(), sub.end());
                    p.insert(p.end(), {OpFindILsb, OpImm, 0u, OpSelect});
                    ++g_dynamic_fallback_hits;
                    return true;
                }
                if (g_force_zero_find_lsb) {
                    p.insert(p.end(), {OpImm, 0u});
                    ++g_dynamic_fallback_hits;
                    return true;
                }
                return false;
            }
        }
        return EmitComputeOffsetOp(p, pass_info, inst, OpFindILsb, 1);
    }""",
)

# 4c. flatten_extended_userdata_pass.cpp: resolve GetAttributeU32 (WorkgroupId / attr74) -> 0 in Stage-2
patch_once(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    """    case IR::Opcode::ReadFirstLane:
        return EmitOperand(p, pass_info, inst->Arg(0));""",
    """    case IR::Opcode::ReadFirstLane:
        return EmitOperand(p, pass_info, inst->Arg(0));
    case IR::Opcode::GetAttributeU32:
        if (g_allow_dynamic_index_fallback) {
            p.insert(p.end(), {OpImm, 0u});
            ++g_dynamic_fallback_hits;
            return true;
        }
        if (!g_suppress_unflattened_log) {
            LogSrtError("Unexpected instruction for offset computation",
                        magic_enum::enum_name(inst->GetOpcode()));
        }
        return false;""",
)

# 4d. flatten_extended_userdata_pass.cpp: run Stage-2 (active bit < 12 -> 0) and Stage-3 (slot 0) only if Stage-1 left unresolved sharps
patch_once(
    "gpu/shadps4/shader_recompiler/ir/passes/flatten_extended_userdata_pass.cpp",
    """    g_suppress_unflattened_log = prev_suppress;
    if (any_unresolved) {
        SrtProgram dummy;""",
    """    if (any_unresolved) {
        g_allow_dynamic_index_fallback = true;
        g_force_zero_find_lsb = false;
        g_dynamic_fallback_hits = 0;
        for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
            bool any_progress = false;
            any_unresolved = false;
            for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                             any_progress, any_unresolved, false);
            }
            if (!any_unresolved || !any_progress) {
                break;
            }
        }
        if (any_unresolved) {
            g_force_zero_find_lsb = true;
            for (u32 pass = 0; pass < MaxFlattenPasses; ++pass) {
                bool any_progress = false;
                any_unresolved = false;
                for (const auto& [sgpr_base, root] : pass_info.srt_roots) {
                    VisitPointer(IR::Value(static_cast<u32>(sgpr_base)), root, pass_info, program,
                                 any_progress, any_unresolved, false);
                }
                if (!any_unresolved || !any_progress) {
                    break;
                }
            }
        }
        g_force_zero_find_lsb = false;
        g_allow_dynamic_index_fallback = false;
        if (g_dynamic_fallback_hits > 0) {
            std::printf("GOW3_SRT_ATTR_FALLBACK: pgm=%#018llx hits=%u unresolved=%d\\n",
                        static_cast<unsigned long long>(info.pgm_hash), g_dynamic_fallback_hits,
                        any_unresolved ? 1 : 0);
        }
    }
    g_suppress_unflattened_log = prev_suppress;
    if (any_unresolved) {
        SrtProgram dummy;""",
)

# 5. vk_pipeline_serialization.cpp: bump shader cache versions (17 -> 18) so patched SRT walkers take effect
patch_once(
    "gpu/shadps4/video_core/renderer_vulkan/vk_pipeline_serialization.cpp",
    """static constexpr u32 ShaderBinaryVersion = 17u; // gow3: SRT BFS traverses Phi and ReadFirstLane
static constexpr u32 ShaderMetaVersion = 17u; // gow3: SRT BFS traverses Phi and ReadFirstLane""",
    """static constexpr u32 ShaderBinaryVersion = 18u; // gow3: SRT stage-2 WorkgroupId/FindILsb fallback
static constexpr u32 ShaderMetaVersion = 18u; // gow3: SRT stage-2 WorkgroupId/FindILsb fallback""",
)

# 6. scripts/launch_env.py: enable hot_pages=1, descriptor_template=1, shadow_rate=0 (when shadows=0), volfog/vol3d=3
patch_once(
    "scripts/launch_env.py",
    """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '1')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '0')""",
    """        updates['GOW3_COALESCE_COMPUTE_BARRIERS'] = env.get('GOW3_COALESCE_COMPUTE_BARRIERS', '1')
        updates['GOW3_DEFERRED_READBACK'] = '0'
        updates['GOW3_STALE_READBACK'] = '0'
        updates['GOW3_READBACK_LINEAR'] = '0'
        updates['GOW3_SCREEN_W'] = env.get('GOW3_SCREEN_W', default_w)
        updates['GOW3_SCREEN_H'] = env.get('GOW3_SCREEN_H', default_h)
        updates['GOW3_HOT_PAGES'] = env.get('GOW3_HOT_PAGES', '1')
        updates['GOW3_SHADOW_RATE'] = env.get('GOW3_SHADOW_RATE', '0' if not shadows_enabled else '1')
        updates['GOW3_VOLFOG_RATE'] = env.get('GOW3_VOLFOG_RATE', '3')
        updates['GOW3_VOL3D_RATE'] = env.get('GOW3_VOL3D_RATE', '3')
        updates['GOW3_DESCRIPTOR_TEMPLATE'] = env.get('GOW3_DESCRIPTOR_TEMPLATE', '1')""",
)

# 7. tools/android/bionic/run-bionic.sh: align post-eval defaults for GoW 2018
patch_once(
    "tools/android/bionic/run-bionic.sh",
    """    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-0}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
    """    export GOW3_HOT_PAGES=${GOW3_HOT_PAGES:-1}
    export GOW3_PREP_WORKERS=${GOW3_PREP_WORKERS:-2}
    export GOW3_PERF_DIAG=${GOW3_PERF_DIAG:-0}
    export GOW3_FAULT_WINDOW=${GOW3_FAULT_WINDOW:-1024}
    export GOW3_COPY_GPU_BUFFERS=${GOW3_COPY_GPU_BUFFERS:-1}
    export GOW3_ASYNC_SHADERS=${GOW3_ASYNC_SHADERS:-1}
    export GOW3_ASYNC_CAPTURE=${GOW3_ASYNC_CAPTURE:-1}
    export GOW3_SHADOWS=${GOW3_SHADOWS:-0}
    export GOW3_SHADOW_RATE=${GOW3_SHADOW_RATE:-0}
    export GOW3_VOLFOG_RATE=${GOW3_VOLFOG_RATE:-3}
    export GOW3_VOL3D_RATE=${GOW3_VOL3D_RATE:-3}
    export GOW3_DESCRIPTOR_TEMPLATE=${GOW3_DESCRIPTOR_TEMPLATE:-1}
    export GOW3_VSYNC=${GOW3_VSYNC:-0}""",
)

print("All GoW 2018 Android FPS + SRT texture patches applied successfully.")

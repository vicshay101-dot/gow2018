#!/usr/bin/env python3
"""Apply the next God of War Android diagnostic update (A-watch + live file state)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def replace_once(src: str, old: str, new: str, label: str) -> str:
    count = src.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one source anchor, found {count}")
    return src.replace(old, new, 1)

def patch_runtime_file(src: str) -> str:
    if "GOW3_FILE_STATE_V2" in src:
        return src
    src = replace_once(
        src,
        'typedef struct { int used, host; Listing *dir; size_t position; char path[512]; } File;',
        '''typedef struct {
    int used, host; Listing *dir; size_t position; char path[512];
    /* GOW3_FILE_STATE_V2: live read state, visible even while host I/O is blocked. */
    unsigned active_reads;
    uint64_t active_requested, active_done;
    int64_t active_pos;
    unsigned long long active_thread;
} File;''',
        "file live-state fields",
    )
    src = replace_once(
        src,
        '''static ssize_t raw_io(int h,int64_t offset,int64_t pos,void *dst,uint64_t len) {
    return offset<0 ? host_read(h,dst,len) : pread(h,dst,len,(off_t)pos);
}
static int64_t transfer_full''',
        '''static ssize_t raw_io(int h,int64_t offset,int64_t pos,void *dst,uint64_t len) {
    return offset<0 ? host_read(h,dst,len) : pread(h,dst,len,(off_t)pos);
}
static void file_io_state(int fd,int delta,uint64_t requested,uint64_t done,int64_t pos) {
    if (fd<3 || fd>=MAX_FILES) return;
    pthread_mutex_lock(&lock);
    File *f=&files[fd];
    if (f->used) {
        if (delta>0) ++f->active_reads;
        else if (delta<0 && f->active_reads) --f->active_reads;
        f->active_requested=requested;
        f->active_done=done;
        f->active_pos=pos;
        f->active_thread=(unsigned long long)(uintptr_t)pthread_self();
    }
    pthread_mutex_unlock(&lock);
}
static int64_t transfer_full''',
        "file active-read state helper",
    )
    src = replace_once(
        src,
        '''static int64_t transfer_full(int fd,int h,char *buffer,uint64_t size,int64_t offset,const char *what) {
    uint64_t total=0;
    int stalls=0;
    char *bounce=NULL;
    while (total<size) {
        int64_t pos = offset<0 ? (int64_t)lseek(h,0,SEEK_CUR) : offset+(int64_t)total;
        ssize_t n;''',
        '''static int64_t transfer_full(int fd,int h,char *buffer,uint64_t size,int64_t offset,const char *what) {
    uint64_t total=0;
    int stalls=0;
    char *bounce=NULL;
    file_io_state(fd,1,size,0,offset);
    while (total<size) {
        int64_t pos = offset<0 ? (int64_t)lseek(h,0,SEEK_CUR) : offset+(int64_t)total;
        file_io_state(fd,0,size,total,pos);
        ssize_t n;''',
        "file active-read begin",
    )
    src = replace_once(
        src,
        '''            if (!bounce) return -ENOMEM;
            continue;''',
        '''            if (!bounce) { file_io_state(fd,-1,size,total,pos); return -ENOMEM; }
            continue;''',
        "file active-read allocation failure",
    )
    src = replace_once(
        src,
        '''        free(bounce);
        return total ? -(int64_t)EIO : -(int64_t)(e ? e : EIO);
    }
    free(bounce);
    if (total<size)''',
        '''        free(bounce);
        file_io_state(fd,-1,size,total,pos);
        return total ? -(int64_t)EIO : -(int64_t)(e ? e : EIO);
    }
    free(bounce);
    file_io_state(fd,-1,size,total,offset<0 ? (int64_t)lseek(h,0,SEEK_CUR) : offset+(int64_t)total);
    if (total<size)''',
        "file active-read end",
    )
    src = replace_once(
        src,
        '''void runtime_file_progress(void) {
    static uint64_t shown_opens=UINT64_MAX, shown_io=UINT64_MAX;''',
        '''void runtime_file_progress(void) {
    static uint64_t shown_opens=UINT64_MAX, shown_io=UINT64_MAX;''',
        "runtime file progress anchor check",
    )
    # Append a live snapshot function after the existing history reporter.
    marker = '''void runtime_file_progress(void) {
    static uint64_t shown_opens=UINT64_MAX, shown_io=UINT64_MAX;'''
    start = src.index(marker)
    end = src.index('\n}', start) + 2
    snapshot = '''
/* GOW3_FILE_STATE_V2: snapshot open descriptors and reads currently inside host I/O. */
void runtime_file_snapshot(void) {
    unsigned shown=0;
    pthread_mutex_lock(&lock);
    for (int fd=3;fd<MAX_FILES && shown<32;++fd) {
        File *f=&files[fd];
        if (!f->used) continue;
        HostStat st; int64_t pos=-1; long long size=-1;
        if (f->host>=0) {
            if (!f->dir) pos=(int64_t)host_lseek(f->host,0,SEEK_CUR);
            if (!host_fstat(f->host,&st)) size=(long long)st.st_size;
        }
        fprintf(stderr,"  FILE_STATE fd=%d pos=%lld size=%lld active=%u active_pos=%lld active_done=%llu/%llu active_tid=%llu %s\\n",
            fd,(long long)pos,size,f->active_reads,(long long)f->active_pos,
            (unsigned long long)f->active_done,(unsigned long long)f->active_requested,
            f->active_thread,f->path);
        ++shown;
    }
    if (!shown) fprintf(stderr,"  FILE_STATE no guest files currently open\\n");
    pthread_mutex_unlock(&lock);
}
'''
    if "void runtime_file_snapshot(void)" not in src:
        src = src[:end] + snapshot + src[end:]
    return src

def patch_runtime_kernel(src: str) -> str:
    if "GOW3_WATCH_A_V1" in src:
        return src
    src = replace_once(src, '#include <unistd.h>\n', '#include <unistd.h>\n#ifndef _WIN32\n#include <sys/mman.h>\n#include <signal.h>\n#include <ucontext.h>\n#endif\n', "watch includes")
    src = replace_once(
        src,
        '''#define SPIN_A_ADDR 0x80209cc70ULL
#define SPIN_A_CALLER 0x8003d514aULL
static void maybe_force_wait_flag(void) {''',
        '''#define SPIN_A_ADDR 0x80209cc70ULL
#define SPIN_A_CALLER 0x8003d514aULL
/* GOW3_WATCH_A_V1: arm a write watch on the page containing A before each matching poll. */
#ifndef _WIN32
static volatile sig_atomic_t watch_a_armed;
static uintptr_t watch_a_page;
static size_t watch_a_page_size;
static int watch_a_original_prot;
static int watch_a_ready;
static int watch_a_find_protection(uintptr_t address,int *prot) {
    FILE *maps=fopen("/proc/self/maps","r");
    if (!maps) return 0;
    char line[512],perm[5]; unsigned long lo,hi; int found=0;
    while (fgets(line,sizeof(line),maps)) {
        if (sscanf(line,"%lx-%lx %4s",&lo,&hi,perm)==3 && address>=lo && address<hi) {
            *prot=(perm[0]=='r'?PROT_READ:0)|(perm[1]=='w'?PROT_WRITE:0)|(perm[2]=='x'?PROT_EXEC:0);
            found=1; break;
        }
    }
    fclose(maps); return found;
}
static void arm_wait_flag_watch(uintptr_t caller) {
    const char *enabled=getenv("GOW3_WATCH_A");
    if (!enabled || enabled[0]!='1' || caller!=SPIN_A_CALLER || watch_a_armed) return;
    if (!watch_a_ready) {
        long ps=sysconf(_SC_PAGESIZE);
        if (ps<=0) return;
        watch_a_page_size=(size_t)ps;
        watch_a_page=SPIN_A_ADDR & ~(uintptr_t)(watch_a_page_size-1);
        if (!watch_a_find_protection(SPIN_A_ADDR,&watch_a_original_prot) || !(watch_a_original_prot&PROT_WRITE)) {
            fprintf(stderr,"GOW3_WATCH_A_V1: cannot watch A; original protection=%d page=%p\\n",watch_a_original_prot,(void*)watch_a_page);
            watch_a_ready=-1; return;
        }
        watch_a_ready=1;
    }
    if (watch_a_ready<0) return;
    if (mprotect((void*)watch_a_page,watch_a_page_size,watch_a_original_prot&~PROT_WRITE)==0) {
        watch_a_armed=1;
        static unsigned arms;
        if (++arms==1 || arms%10000==0)
            fprintf(stderr,"GOW3_WATCH_A_V1: armed page=%p original_prot=%d arms=%u\\n",(void*)watch_a_page,watch_a_original_prot,arms);
    }
}
int runtime_watch_handle_fault(int sig,siginfo_t *info,void *context) {
    if (sig!=SIGSEGV || !info || !watch_a_armed ||
        (((uintptr_t)info->si_addr)&~(uintptr_t)(watch_a_page_size-1))!=watch_a_page) return 0;
    GuestRegs regs={0};
    int guest=guest_cpu_signal_regs(context,&regs);
    uintptr_t hostpc=guest_cpu_host_pc(context);
    fprintf(stderr,"GOW3_WATCH_A_V1: page write addr=%p guest=%d rip=%#llx image_off=%#llx hostpc=%p A=%d B=%u tid=%ld\\n",
        info->si_addr,guest,(unsigned long long)regs.rip,
        (unsigned long long)(regs.rip>=0x800104000ULL?regs.rip-0x800104000ULL:0),
        (void*)hostpc,(int)*(volatile int32_t*)(uintptr_t)SPIN_A_ADDR,
        (unsigned)*(volatile uint8_t*)(uintptr_t)0x802b172e1ULL,(long)(uintptr_t)pthread_self());
    if (mprotect((void*)watch_a_page,watch_a_page_size,watch_a_original_prot)!=0) {
        fprintf(stderr,"GOW3_WATCH_A_V1: failed to restore page protection errno=%d\\n",errno);
        return 0;
    }
    watch_a_armed=0;
    return 1;
}
#else
static void arm_wait_flag_watch(uintptr_t caller) { (void)caller; }
#endif
static void maybe_force_wait_flag(void) {''',
        "A watch implementation",
    )
    src = replace_once(
        src,
        '''    const char *off=getenv("GOW3_NO_FORCE_A");
    if (off && off[0]=='1') { done=1; return; }''',
        '''    const char *off=getenv("GOW3_NO_FORCE_A");
    const char *watch=getenv("GOW3_WATCH_A");
    if ((off && off[0]=='1') || (watch && watch[0]=='1')) { done=1; return; }''',
        "disable force while A watch is enabled",
    )
    src = replace_once(
        src,
        '''static ABI int32_t kernel_usleep(uint32_t usec) { note_usleep_spin(); sleep_ns((uint64_t)usec*1000); return 0; }
static ABI int32_t posix_usleep(uint32_t usec) { note_usleep_spin(); sleep_ns((uint64_t)usec*1000); return 0; }''',
        '''static ABI int32_t kernel_usleep(uint32_t usec) {
    uintptr_t caller=guest_cpu_return_address((uintptr_t)__builtin_return_address(0));
    note_usleep_spin(); arm_wait_flag_watch(caller); sleep_ns((uint64_t)usec*1000); return 0;
}
static ABI int32_t posix_usleep(uint32_t usec) {
    uintptr_t caller=guest_cpu_return_address((uintptr_t)__builtin_return_address(0));
    note_usleep_spin(); arm_wait_flag_watch(caller); sleep_ns((uint64_t)usec*1000); return 0;
}''',
        "arm A watch at matching usleep loop",
    )
    return src

def patch_probe(src: str) -> str:
    if "runtime_file_snapshot(void);" not in src:
        src = replace_once(
            src,
            "void runtime_file_progress(void);",
            "void runtime_file_progress(void);\nvoid runtime_file_snapshot(void);",
            "probe file snapshot declaration",
        )
    if "runtime_file_snapshot();" not in src:
        src = replace_once(
            src,
            'runtime_file_progress(); }',
            'runtime_file_progress(); runtime_file_snapshot(); }',
            "probe heartbeat live file snapshot",
        )
    if "runtime_watch_handle_fault" not in src:
        src = replace_once(
            src,
            '''#ifndef _WIN32
static void fault(int sig, siginfo_t *info, void *context) {
    /* GPU page tracking (write-protected guest pages) is resolved first. */
    if (gpu_enabled && sig == SIGSEGV && gow3gpu_handle_fault(context, info->si_addr)) return;''',
            '''#ifndef _WIN32
int runtime_watch_handle_fault(int sig,siginfo_t *info,void *context);
static void fault(int sig, siginfo_t *info, void *context) {
    /* Diagnostic write watch for the game-global wait flag A. */
    if (runtime_watch_handle_fault(sig,info,context)) return;
    /* GPU page tracking (write-protected guest pages) is resolved next. */
    if (gpu_enabled && sig == SIGSEGV && gow3gpu_handle_fault(context, info->si_addr)) return;''',
            "probe A watch signal dispatch",
        )
    return src

changes = {
    Path("src/runtime_file.c"): patch_runtime_file,
    Path("src/runtime_kernel.c"): patch_runtime_kernel,
    Path("src/probe.c"): patch_probe,
}
updated = {}
for rel, patch in changes.items():
    path = ROOT / rel
    if not path.is_file():
        raise RuntimeError(f"Required source file missing: {rel}")
    updated[path] = patch(path.read_text(encoding="utf-8"))
for path, content in updated.items():
    path.write_text(content, encoding="utf-8")
    print(f"Patched {path.relative_to(ROOT)}")

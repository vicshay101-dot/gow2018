#!/usr/bin/env python3
"""Apply the God of War 2018 Android diagnostic patch set."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def replace_once(src: str, old: str, new: str, label: str) -> str:
    count = src.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one source anchor, found {count}")
    return src.replace(old, new, 1)

def patch_runtime_file(src: str) -> str:
    if "GOW3_IO_HISTORY_V1" in src:
        return src
    src = replace_once(
        src,
        "static uint64_t bytes_read;\nstatic pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;",
        """static uint64_t bytes_read;
/* GOW3_IO_HISTORY_V1: bounded history for async asset-stream diagnostics. */
typedef struct {
    int fd;
    uint64_t requested, actual;
    int64_t offset;
    unsigned long long thread;
    char path[512];
} RuntimeFileEvent;
static RuntimeFileEvent recent_opens[8], recent_io[8];
static uint64_t open_event_count, io_event_count;
static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;""",
        "runtime_file event history declarations",
    )
    src = replace_once(
        src,
        """    ++opens;
    unsigned long opened_now=opens;
    pthread_mutex_unlock(&lock);""",
        """    ++opens;
    unsigned long opened_now=opens;
    {
        RuntimeFileEvent *ev=&recent_opens[open_event_count++ % 8];
        *ev=(RuntimeFileEvent){.fd=fd,.requested=(uint64_t)(s.st_size>0?s.st_size:0),
            .actual=(uint64_t)(s.st_size>0?s.st_size:0),.offset=0,
            .thread=(unsigned long long)(uintptr_t)pthread_self()};
        snprintf(ev->path,sizeof(ev->path),"%s",guest);
    }
    pthread_mutex_unlock(&lock);""",
        "runtime_file open history",
    )
    src = replace_once(
        src,
        """static int host_fd(int fd) {
    if (fd>=0 && fd<3) return fd;
    File *f=get(fd);
    return f ? f->host : -1;
}""",
        """static int host_fd(int fd) {
    if (fd>=0 && fd<3) return fd;
    File *f=get(fd);
    return f ? f->host : -1;
}
static void record_file_io(int fd,uint64_t requested,uint64_t actual,int64_t offset) {
    pthread_mutex_lock(&lock);
    RuntimeFileEvent *ev=&recent_io[io_event_count++ % 8];
    *ev=(RuntimeFileEvent){.fd=fd,.requested=requested,.actual=actual,.offset=offset,
        .thread=(unsigned long long)(uintptr_t)pthread_self()};
    if (fd>=0 && fd<3) snprintf(ev->path,sizeof(ev->path),"stdio:%d",fd);
    else if (fd>=0 && fd<MAX_FILES && files[fd].used)
        snprintf(ev->path,sizeof(ev->path),"%s",files[fd].path);
    else snprintf(ev->path,sizeof(ev->path),"<closed fd>");
    pthread_mutex_unlock(&lock);
}""",
        "runtime_file I/O recorder",
    )
    src = replace_once(
        src,
        """    __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,total,__ATOMIC_RELAXED);
    return (int64_t)total;
}
static int64_t do_pread""",
        """    __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,total,__ATOMIC_RELAXED);
    record_file_io(fd,size,total,-1);
    return (int64_t)total;
}
static int64_t do_pread""",
        "runtime_file read history",
    )
    src = replace_once(
        src,
        """    __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,total,__ATOMIC_RELAXED);
    return (int64_t)total;
}
static int64_t do_write""",
        """    __atomic_add_fetch(&reads,1,__ATOMIC_RELAXED); __atomic_add_fetch(&bytes_read,total,__ATOMIC_RELAXED);
    record_file_io(fd,size,total,offset);
    return (int64_t)total;
}
static int64_t do_write""",
        "runtime_file pread history",
    )
    src = replace_once(
        src,
        """void runtime_file_stats(unsigned long long *o,unsigned long long *r,unsigned long long *b,unsigned long long *m) {
    *o=opens; *r=reads; *b=bytes_read; *m=missing;
}""",
        """void runtime_file_stats(unsigned long long *o,unsigned long long *r,unsigned long long *b,unsigned long long *m) {
    *o=opens; *r=reads; *b=bytes_read; *m=missing;
}
/* Called by the 5-second heartbeat. Prints only when new I/O was recorded. */
void runtime_file_progress(void) {
    static uint64_t shown_opens=UINT64_MAX, shown_io=UINT64_MAX;
    RuntimeFileEvent op[8], io[8];
    uint64_t no,ni;
    pthread_mutex_lock(&lock);
    no=open_event_count; ni=io_event_count;
    if (no==shown_opens && ni==shown_io) { pthread_mutex_unlock(&lock); return; }
    memcpy(op,recent_opens,sizeof(op));
    memcpy(io,recent_io,sizeof(io));
    pthread_mutex_unlock(&lock);
    shown_opens=no; shown_io=ni;
    fprintf(stderr,"File history: recent opens (oldest first):\\n");
    uint64_t first=no>8?no-8:0;
    for (uint64_t n=first;n<no;++n) {
        const RuntimeFileEvent *e=&op[n%8];
        fprintf(stderr,"  OPEN fd=%d size=%llu tid=%llu %s\\n",e->fd,
            (unsigned long long)e->requested,e->thread,e->path);
    }
    fprintf(stderr,"File history: recent reads (oldest first):\\n");
    first=ni>8?ni-8:0;
    for (uint64_t n=first;n<ni;++n) {
        const RuntimeFileEvent *e=&io[n%8];
        fprintf(stderr,"  %s fd=%d got=%llu/%llu offset=%lld tid=%llu %s\\n",
            e->offset<0?"READ":"PREAD",e->fd,(unsigned long long)e->actual,
            (unsigned long long)e->requested,(long long)e->offset,e->thread,e->path);
    }
}""",
        "runtime_file progress reporter",
    )
    return src

def patch_probe(src: str) -> str:
    if "runtime_file_progress(void);" in src:
        return src
    src = replace_once(
        src,
        "void runtime_file_stats(unsigned long long *o,unsigned long long *r,unsigned long long *b,unsigned long long *m);",
        "void runtime_file_stats(unsigned long long *o,unsigned long long *r,unsigned long long *b,unsigned long long *m);\nvoid runtime_file_progress(void);",
        "probe file stats declaration",
    )
    src = replace_once(
        src,
        """        { unsigned long long fo,fr,fb,fm; runtime_file_stats(&fo,&fr,&fb,&fm); fprintf(stderr,"Heartbeat files: opens=%llu reads=%llu read=%llu MiB not_found=%llu\\n",fo,fr,fb/1048576ULL,fm); }""",
        """        { unsigned long long fo,fr,fb,fm; runtime_file_stats(&fo,&fr,&fb,&fm); fprintf(stderr,"Heartbeat files: opens=%llu reads=%llu read=%llu MiB not_found=%llu\\n",fo,fr,fb/1048576ULL,fm); runtime_file_progress(); }""",
        "probe heartbeat file progress",
    )
    return src

def patch_frame_capture(src: str) -> str:
    if "GOW3_FRAME_TRACE_V1" in src:
        return src
    if "#include <cstdio>" not in src:
        src = replace_once(src, "#include <cstdlib>\n", "#include <cstdlib>\n#include <cstdio>\n", "frame capture cstdio include")
    src = replace_once(
        src,
        """void FrameCapture::AddDisplayBuffer(VAddr address) {
    std::scoped_lock lk{display_mutex};
    if (std::ranges::find(display_buffers, address) == display_buffers.end()) {
        display_buffers.push_back(address);""",
        """void FrameCapture::AddDisplayBuffer(VAddr address) {
    std::scoped_lock lk{display_mutex};
    if (std::ranges::find(display_buffers, address) == display_buffers.end()) {
        if (const char* trace=std::getenv("GOW3_FRAME_TRACE"); trace && trace[0]=='1')
            std::fprintf(stderr,"GOW3_FRAME_TRACE_V1: registered display buffer %llx\\n",(unsigned long long)address);
        display_buffers.push_back(address);""",
        "frame capture display registration trace",
    )
    src = replace_once(
        src,
        """    // Frame boundaries in the command stream: the pass that writes a display buffer as its only
    // target. gow3: God of War III also draws scene passes (two targets) into display buffers.
    display = display && targets.size() == 1;""",
        """    // Optional render-target trace. It does not change pass selection or rendering.
    if (const char* trace=std::getenv("GOW3_FRAME_TRACE"); trace && trace[0]=='1') {
        static u32 traced=0;
        if (display || traced<48) {
            ++traced;
            std::fprintf(stderr,"GOW3_FRAME_TRACE_V1: BeginPass colors=%u display=%d",num_colors,display?1:0);
            for (const auto& target:targets)
                std::fprintf(stderr," [%s]",Describe(target).c_str());
            if (depth) std::fprintf(stderr," depth=[%s]",Describe(ToTarget(*depth)).c_str());
            std::fprintf(stderr,"\\n");
        }
    }
    // Frame boundaries in the command stream: the pass that writes a display buffer as its only
    // target. gow3: God of War III also draws scene passes (two targets) into display buffers.
    display = display && targets.size() == 1;""",
        "frame capture render target trace",
    )
    return src

changes = {
    Path("src/runtime_file.c"): patch_runtime_file,
    Path("src/probe.c"): patch_probe,
    Path("gpu/shadps4/video_core/renderer_vulkan/vk_frame_capture.cpp"): patch_frame_capture,
}
updated = {}
for rel, patch in changes.items():
    path = ROOT / rel
    if not path.is_file():
        raise RuntimeError(f"Required source file missing: {rel}")
    updated[path] = patch(path.read_text(encoding="utf-8"))
for path, content in updated.items():
    path.write_text(content, encoding="utf-8")
    print(f"Patched {path.relative_to(ROOT)}")

#!/usr/bin/env python3
"""Enable the A write watch automatically and remove the old forced-A test."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def replace_once(src: str, old: str, new: str, label: str) -> str:
    count = src.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one source anchor, found {count}")
    return src.replace(old, new, 1)


def patch_kernel(src: str) -> str:
    if "GOW3_WATCH_A_V2" in src:
        return src
    if "GOW3_WATCH_A_V1" not in src:
        raise RuntimeError("A-watch V1 implementation not found; refusing to patch an unexpected source")

    old_guard = '''static void arm_wait_flag_watch(uintptr_t caller) {
    const char *enabled=getenv("GOW3_WATCH_A");
    if (!enabled || enabled[0]!='1' || caller!=SPIN_A_CALLER || watch_a_armed) return;'''
    new_guard = '''static void arm_wait_flag_watch(uintptr_t caller) {
    /* GOW3_WATCH_A_V2: automatic activation; no environment variable required. */
    if (caller!=SPIN_A_CALLER || watch_a_armed) return;'''
    src = replace_once(src, old_guard, new_guard, "automatic A-watch activation")

    old_mprotect = '''    if (mprotect((void*)watch_a_page,watch_a_page_size,watch_a_original_prot&~PROT_WRITE)==0) {
        watch_a_armed=1;
        static unsigned arms;
        if (++arms==1 || arms%10000==0)
            fprintf(stderr,"GOW3_WATCH_A_V1: armed page=%p original_prot=%d arms=%u\\n",(void*)watch_a_page,watch_a_original_prot,arms);
    }'''
    new_mprotect = '''    static unsigned arms;
    if (mprotect((void*)watch_a_page,watch_a_page_size,watch_a_original_prot&~PROT_WRITE)==0) {
        watch_a_armed=1;
        if (++arms==1 || arms%10000==0)
            fprintf(stderr,"GOW3_WATCH_A_V2: armed automatically page=%p original_prot=%d arms=%u\\n",(void*)watch_a_page,watch_a_original_prot,arms);
    } else {
        static unsigned failures;
        if (++failures<=10 || failures%1000==0)
            fprintf(stderr,"GOW3_WATCH_A_V2: mprotect arm failed errno=%d page=%p failures=%u\\n",errno,(void*)watch_a_page,failures);
    }'''
    src = replace_once(src, old_mprotect, new_mprotect, "A-watch arm diagnostics")

    # Remove the old experimental write to A entirely. The spin logger remains passive.
    start = src.find("static void maybe_force_wait_flag(void) {")
    end = src.find("static void note_usleep_spin(void) {", start)
    if start < 0 or end < 0:
        raise RuntimeError("could not locate the old force-A test")
    src = src[:start] + '''/* GOW3_WATCH_A_V2: the old test that wrote A=1 is deliberately disabled. */
static void maybe_force_wait_flag(void) { }
''' + src[end:]
    return src


def patch_probe(src: str) -> str:
    if "GOW3_WATCH_A_V2_ORDER" in src:
        return src
    old = '''static void fault(int sig, siginfo_t *info, void *context) {
    /* Diagnostic write watch for the game-global wait flag A. */
    if (runtime_watch_handle_fault(sig,info,context)) return;
    /* GPU page tracking (write-protected guest pages) is resolved next. */
    if (gpu_enabled && sig == SIGSEGV && gow3gpu_handle_fault(context, info->si_addr)) return;'''
    new = '''static void fault(int sig, siginfo_t *info, void *context) {
    /* GPU page tracking gets first chance to resolve its own protected-page faults. */
    if (gpu_enabled && sig == SIGSEGV && gow3gpu_handle_fault(context, info->si_addr)) return;
    /* GOW3_WATCH_A_V2_ORDER: then handle the diagnostic watch on the A page. */
    if (runtime_watch_handle_fault(sig,info,context)) return;'''
    return replace_once(src, old, new, "signal-handler fault dispatch order")


changes = {
    Path("src/runtime_kernel.c"): patch_kernel,
    Path("src/probe.c"): patch_probe,
}
updated = {}
for rel, patch in changes.items():
    path = ROOT / rel
    if not path.is_file():
        raise RuntimeError(f"Required source file missing: {rel}")
    updated[path] = patch(path.read_text(encoding="utf-8"))

for path, content in updated.items():
    path.write_text(content, encoding="utf-8")
    print(f"Patched {path.relative_to(ROOT)}")

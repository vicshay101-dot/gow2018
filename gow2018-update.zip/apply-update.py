#!/usr/bin/env python3
"""
Script de atualização automática para o gow2018 (Sequência de Debug e Patch).
Passo 1: Remove o mprotect / auto-arm da página 0x80209c000 (GOW3_WATCH_A).
Passo 2: Adiciona o dump do RIP no heartbeat com tgkill(SIGUSR2) e handler ucontext.
"""

import os
import re

def apply_patch():
    print("[*] Iniciando patch de atualização do gow2018 conforme ordem estipulada...")
    
    target_files = ["runtime_memory.c", "kernel_stubs.inc", "stubs.c", "heartbeat.c"]
    patched = False
    
    # 1. Desativar o mprotect / watch de 0x80209c000
    for filename in target_files:
        if os.path.exists(filename):
            print(f"[*] Analisando arquivo para remoção do watch/mprotect: {filename}")
            with open(filename, "r", encoding="utf-8") as f:
                code = f.read()
                
            # Comenta chamadas de mprotect na página 0x80209c000 ou GOW3_WATCH_A
            new_code = re.sub(
                r'(mprotect\s*\(\s*\(void\*\)\s*0x80209c000.*?\))',
                r'/* REMOVIDO / DESLIGADO (Debug Watch): \1 */',
                code
            )
            
            # Também desativa referências explícitas a GOW3_WATCH_A se houverem
            new_code = new_code.replace("GOW3_WATCH_A", "GOW3_WATCH_A_DISABLED")
            
            if new_code != code:
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(new_code)
                print(f"[+] Sucesso: Watch/mprotect desativado em {filename}")
                patched = True

    # 2. Inserir dump do RIP da thread principal no heartbeat (tgkill + handler ucontext)
    heartbeat_target = "runtime_memory.c" if os.path.exists("runtime_memory.c") else ("stubs.c" if os.path.exists("stubs.c") else None)
    if heartbeat_target:
        print(f"[*] Injetando handler de sinal e tgkill(SIGUSR2) em {heartbeat_target}")
        with open(heartbeat_target, "r", encoding="utf-8") as f:
            content = f.read()
            
        snippet = """
// --- PATCH: Heartbeat RIP Dump (tgkill + SIGUSR2) ---
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <ucontext.h>

static void gow3_sigusr2_handler(int sig, siginfo_t *info, void *context) {
    ucontext_t *uc = (ucontext_t *)context;
    #if defined(__x86_64__)
    unsigned long rip = uc->uc_mcontext.gregs[REG_RIP];
    unsigned long rel_rip = rip - g_image_base;
    // Se RIP estiver em memcpy/handler -> watch. Se estiver em 0x800... -> spin-wait (fences de compute vqid=4)
    ALOGI("[GOW3_DEBUG_RIP] RIP: 0x%lx | Offset (rip - image_base): 0x%lx", rip, rel_rip);
    #endif
}

__attribute__((constructor)) static void init_gow3_debug_handler() {
    struct sigaction sa;
    sa.sa_sigaction = gow3_sigusr2_handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR2, &sa, NULL);
}

void trigger_gow3_heartbeat_check(pid_t main_tid) {
    tgkill(getpid(), main_tid, SIGUSR2);
}
// ----------------------------------------------------
"""
        if "gow3_sigusr2_handler" not in content:
            content = snippet + "
" + content
            with open(heartbeat_target, "w", encoding="utf-8") as f:
                f.write(content)
            print("[+] Sucesso: Handler e tgkill adicionados ao código.")
            patched = True

    if not patched:
        print("[-] Nenhum arquivo alvo encontrado no diretório atual. Certifique-se de executar na raiz do repositório.")
    else:
        print("[+] Atualização concluída com sucesso! Gere o APK e teste no Poco F6.")

if __name__ == "__main__":
    apply_patch()
